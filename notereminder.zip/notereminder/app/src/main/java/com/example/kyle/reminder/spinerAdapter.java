package com.example.kyle.reminder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

/**
 * Created by Zahra on 5/20/2019.
 */

public class spinerAdapter extends BaseAdapter {
    Context context;
    private String[] name;
    private int[] pics;
    private LayoutInflater inflater;

    public spinerAdapter(Context context,  int[] pics) {
        this.context = context;
        this.name = name;
        this.pics = pics;
       inflater =  LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return pics.length;
    }

    @Override
    public Object getItem(int position) {
        return pics[position];
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ViewHolder holder;
        if (convertView==null){
            convertView = inflater.inflate(R.layout.custom_spiner_item,viewGroup,false);
            holder = new ViewHolder();
            holder.fontpic=(ImageView) convertView.findViewById(R.id.fontsPic);
         //   holder.fontname= (TextView) convertView.findViewById(R.id.fontsname);
            convertView.setTag(holder);

        }else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.fill(position);
        return convertView;
    }

    public class ViewHolder{
        public ImageView fontpic;
       // public TextView fontname;

        public void fill(int position){
            fontpic.setImageResource(pics[position]);
           // fontname.setText(name[position]);
        }
    }
}
