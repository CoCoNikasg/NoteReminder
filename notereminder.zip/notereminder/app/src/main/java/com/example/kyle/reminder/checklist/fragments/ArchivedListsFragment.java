package com.example.kyle.reminder.checklist.fragments;


import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.kyle.reminder.R;
import com.example.kyle.reminder.checklist.adapters.ArchivedListsAdapter;
import com.example.kyle.reminder.checklist.helpers.TinyListSQLHelper;
import com.example.kyle.reminder.checklist.models.TaskList;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;


public class ArchivedListsFragment extends BaseFragment {

    @BindView(R.id.archived_list_recycler_view)
    RecyclerView archivedListsRecyclerView;
    ArrayList<TaskList> list;
    private ArchivedListsAdapter mAdapter;
    public ArchivedListsFragment() {
        // Required empty public constructor
    }


    public static ArchivedListsFragment getInstance() {
        return new ArchivedListsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.todo_fragment_archived_lists, container, false);
        ButterKnife.bind(this, view);

        SearchView searchView = view.findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                filter(s.toLowerCase());
                return false;
            }
        });
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupViews();
    }
    void filter(String text){
        ArrayList<TaskList> temp = new ArrayList();
        for(TaskList d: list){
            if(d.getTitle().toLowerCase().contains(text)){
                temp.add(d);
            }
        }

        mAdapter.updateList(temp);
    }

    @Override
    void setupViews() {
        archivedListsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        list=TinyListSQLHelper.getSqlHelper(getActivity()).getTaskLists(true);
        mAdapter = new ArchivedListsAdapter(TinyListSQLHelper.getSqlHelper(getActivity()).getTaskLists(true), getActivity());
        archivedListsRecyclerView.setAdapter(mAdapter);
        ItemTouchHelper.SimpleCallback simpleItemTouchCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(final RecyclerView.ViewHolder viewHolder, int direction) {
                /* Unarchiving the swiped item. */
                final TaskList taskListToArchive = ((ArchivedListsAdapter) archivedListsRecyclerView.getAdapter()).getItem(viewHolder.getAdapterPosition());
                taskListToArchive.setIsArchived(false);
                TinyListSQLHelper.getSqlHelper(getActivity()).addOrUpdateTaskList(taskListToArchive);
                ((ArchivedListsAdapter) archivedListsRecyclerView.getAdapter()).removeItem(viewHolder.getAdapterPosition());
            }
        };
        new ItemTouchHelper(simpleItemTouchCallback).attachToRecyclerView(archivedListsRecyclerView);
    }

    /**
     * Method used to redraw the items inside the main RecyclerView
     */
    @Override
    public void redrawItems() {
        ((ArchivedListsAdapter) archivedListsRecyclerView.getAdapter()).replaceWith(TinyListSQLHelper.getSqlHelper(getActivity()).getTaskLists(true));
    }

    @Override
    public void onStart() {
        super.onStart();
        /* Redraw items when this fragment is first viewed by the user. */
        redrawItems();
    }

}
