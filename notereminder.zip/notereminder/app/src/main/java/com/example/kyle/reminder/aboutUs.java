package com.example.kyle.reminder;

import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.TextView;


public class aboutUs extends AppCompatActivity {
    SharedPreferences shared;
    TextView versionName;
    Toolbar toolbaar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        shared = this.getSharedPreferences("fonts", MODE_PRIVATE);

        if (shared.getInt("selectedtheme", 0) == 0 ){
            getTheme().applyStyle(R.style.AppTheme,true);
        } else  if (shared.getInt("selectedtheme", 0) ==1 ) {
            getTheme().applyStyle(R.style.greenTheme,true);
        } else {
            getTheme().applyStyle(R.style.violetTheme,true);
        }

        setContentView(R.layout.activity_about_us);
        versionName = findViewById(R.id.versionName);
        versionName.setText(BuildConfig.VERSION_NAME+"");

        toolbaar = findViewById(R.id.toolbaar);
        setSupportActionBar(toolbaar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbaar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}
