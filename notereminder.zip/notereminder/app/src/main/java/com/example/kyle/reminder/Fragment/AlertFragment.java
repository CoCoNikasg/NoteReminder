package com.example.kyle.reminder.Fragment;


import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.kyle.reminder.R;
import com.example.kyle.reminder.ReminderFragment;
import com.example.kyle.reminder.ReminderParams;
import com.example.kyle.reminder.ReminderType;


public class AlertFragment extends Fragment {
    View view;
    private FragmentManager mFragmentManager;

    public AlertFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_alert, container, false);


        mFragmentManager = getActivity().getSupportFragmentManager();
        Bundle args = new Bundle();
        args.putSerializable(ReminderParams.TYPE, ReminderType.ALERT);
        Fragment reminderFragment = new ReminderFragment();
        reminderFragment.setArguments(args);
        mFragmentManager.beginTransaction().add(R.id.content_frame, reminderFragment).commit();


        return view;
    }



}
