package com.example.kyle.reminder.font;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import androidx.appcompat.widget.AppCompatTextView;
import android.util.AttributeSet;
import android.util.TypedValue;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Zahra on 5/19/2019.
 */

public class TextviewFonttitle extends AppCompatTextView {
    SharedPreferences shared;
    SharedPreferences.Editor editorU ;
    int s, fontSize;
    String txtColor;
    String path_font1 = "fonts/agnesregular.ttf";
    String path_font2 = "fonts/stardust.ttf";
    String path_font3 = "fonts/antaro.ttf";
    public TextviewFonttitle(Context context) {
        super(context);

        shared = context.getSharedPreferences("fonts", MODE_PRIVATE);
        editorU = shared.edit();
        s = shared.getInt("font", 4);
        fontSize = shared.getInt("fontsize", 0);
        txtColor = shared.getString("textcolor",null);
        if(!shared.contains("textcolor"))
        {
            txtColor= "000000";
        }

        //Toast.makeText(context, s+"" , Toast.LENGTH_SHORT).show();

        if (s==0) {
            Typeface font = Typeface.createFromAsset(context.getAssets(), path_font3);
            setTypeface(font);
        }else if (s==1){
            Typeface font = Typeface.createFromAsset(context.getAssets(), path_font2);
            setTypeface(font);
        }else if (s==2){
            Typeface font = Typeface.createFromAsset(context.getAssets(),path_font1);
            setTypeface(font);
           setTextSize(TypedValue.COMPLEX_UNIT_PX,24);
        }


        if ( fontSize == 0 ){
            setTextSize(TypedValue.COMPLEX_UNIT_SP,20);
        } else if ( fontSize == 1 ) {
            setTextSize(TypedValue.COMPLEX_UNIT_SP,24);
        }else{
            setTextSize(TypedValue.COMPLEX_UNIT_SP,28);
        }

        setTextColor(Color.parseColor("#"+txtColor));

      /*  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
        }else {
            setTextColor(Color.parseColor("#"+txtColor));

        }*/

    }


    public TextviewFonttitle(Context context, AttributeSet attrs) {
        super(context, attrs);
        shared = context.getSharedPreferences("fonts", MODE_PRIVATE);
        editorU = shared.edit();
        s = shared.getInt("font", 0);
        fontSize = shared.getInt("fontsize", 0);
        txtColor = shared.getString("textcolor",null);
        if(!shared.contains("textcolor"))
        {
            txtColor= "000000";
        }

        if (s==0) {
            Typeface font = Typeface.createFromAsset(context.getAssets(), path_font3);
            setTypeface(font);
        }else if (s==1){
            Typeface font = Typeface.createFromAsset(context.getAssets(),path_font2);
            setTypeface(font);
        }else if (s==2){
            Typeface font = Typeface.createFromAsset(context.getAssets(), path_font1);
            setTypeface(font);
        }


        if ( fontSize == 0 ){
            setTextSize(TypedValue.COMPLEX_UNIT_SP,20);
        } else if ( fontSize == 1 ) {
            setTextSize(TypedValue.COMPLEX_UNIT_SP,24);
        }else{
            setTextSize(TypedValue.COMPLEX_UNIT_SP,28);
        }


        setTextColor(Color.parseColor("#"+txtColor));

      /*  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
        }else {
            setTextColor(Color.parseColor("#"+txtColor));

        }*/


    }

    public TextviewFonttitle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        shared = context.getSharedPreferences("fonts", MODE_PRIVATE);
        editorU = shared.edit();
        s = shared.getInt("font", 0);
        fontSize = shared.getInt("fontsize", 0);
        txtColor = shared.getString("textcolor",null);
        if(!shared.contains("textcolor"))
        {
            txtColor= "000000";
        }


        if (s==0) {
            Typeface font = Typeface.createFromAsset(context.getAssets(), path_font3);
            setTypeface(font);
        }else if (s==1){
            Typeface font = Typeface.createFromAsset(context.getAssets(), path_font2);
            setTypeface(font);
        }else if (s==2){
            Typeface font = Typeface.createFromAsset(context.getAssets(), path_font1);
            setTypeface(font);
        }


        if ( fontSize == 0 ){
            setTextSize(TypedValue.COMPLEX_UNIT_SP,20);
        } else if ( fontSize == 1 ) {
            setTextSize(TypedValue.COMPLEX_UNIT_SP,24);
        }else{
            setTextSize(TypedValue.COMPLEX_UNIT_SP,28);
        }

        setTextColor(Color.parseColor("#"+txtColor));

      /*  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
        }else {
            setTextColor(Color.parseColor("#"+txtColor));

        }*/

    }


}
