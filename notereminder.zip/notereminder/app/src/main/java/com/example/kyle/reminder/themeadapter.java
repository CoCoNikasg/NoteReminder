package com.example.kyle.reminder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Created by Zahra on 5/29/2019.
 */

public class themeadapter extends BaseAdapter {
    Context context;
    private String[] name;
    private int[] pics;
    private LayoutInflater inflater;

    public themeadapter(Context context, String[] name) {
        this.context = context;
        this.name = name;
        inflater =  LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return name.length;
    }

    @Override
    public Object getItem(int position) {
        return name[position];
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        themeadapter.ViewHolder holder;
        if (convertView==null){
            convertView = inflater.inflate(R.layout.activity_theme_spiner_item,viewGroup,false);
            holder = new ViewHolder();
          //  holder.themepic=(ImageView) convertView.findViewById(R.id.themePic);
            holder.themename= (TextView) convertView.findViewById(R.id.themename);
            convertView.setTag(holder);

        }else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.fill(position);
        return convertView;
    }

    public class ViewHolder{
        public TextView themename;

        public void fill(int position){
            themename.setText(name[position]);
        }
    }
}
