package com.example.kyle.reminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;

import com.flask.colorpicker.ColorPickerView;
import com.flask.colorpicker.OnColorSelectedListener;
import com.flask.colorpicker.builder.ColorPickerClickListener;
import com.flask.colorpicker.builder.ColorPickerDialogBuilder;


public class SettingActivity extends AppCompatActivity {
    android.widget.Spinner fontSpinner , fontSizeSpinner , themeSpinner;
    ImageView selectColor;
    String[] themes = {"blue theme","green theme","violet theme"};
    String[] size = {"small","medium","large"};
    int[] inti = {0xffffffff};
    int [] pictures = {R.drawable.anta,R.drawable.stard,R.drawable.reg};
    Toolbar toolbaar;
    SharedPreferences shared;
    SharedPreferences.Editor editorU ;
    private View root;
    private int currentBackgroundColor = 0xffffffff;
    Button savebtn;
    Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        shared = this.getSharedPreferences("fonts", MODE_PRIVATE);
        editorU = shared.edit();

        if (shared.getInt("selectedtheme", 0) == 0) {
                getTheme().applyStyle(R.style.AppTheme, true);
            } else if (shared.getInt("selectedtheme", 0) == 1) {
                getTheme().applyStyle(R.style.greenTheme, true);
            } else {
                getTheme().applyStyle(R.style.violetTheme, true);
            }


        setContentView(R.layout.activity_setting);
        findview();
        setSupportActionBar(toolbaar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbaar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });



        fontspinnermethod();
        fontSizespinnermethod();
        themeSpinner();
        selectColor = findViewById(R.id.selectcolor);
        selectColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                colorPicker();
            }
        });

savebtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        AlarmManager alm = (AlarmManager)SettingActivity.this.getSystemService(Context.ALARM_SERVICE);
        alm.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, PendingIntent.getActivity(SettingActivity.this, 0, new Intent(SettingActivity.this, this.getClass()), 0));
        android.os.Process.killProcess(android.os.Process.myPid());
    }
});


    }

    private void findview() {
        fontSpinner = findViewById(R.id.fontSpinner);
        fontSizeSpinner = findViewById(R.id.fontSizeSpinner);
        themeSpinner = findViewById(R.id.themeSpinner);
        toolbaar = findViewById(R.id.toolbaar);
       // changeBackgroundColor(currentBackgroundColor);
        savebtn = findViewById(R.id.btnSave);



    }

    private void colorPicker(){

        ColorPickerDialogBuilder
                .with(SettingActivity.this)
                .setTitle("Choose color")
                .initialColors(inti)
                .wheelType(ColorPickerView.WHEEL_TYPE.CIRCLE)
                .density(12)
                .setOnColorSelectedListener(new OnColorSelectedListener() {
                    @Override
                    public void onColorSelected(int selectedColor) {
                        //  Toast("onColorSelected: 0x" + Integer.toHexString(selectedColor));
                        //   Toast.makeText(SettingActivity.this, "onColorSelected: 0x" + Integer.toHexString(selectedColor), Toast.LENGTH_SHORT).show();
                    }
                })
                .setPositiveButton("ok", new ColorPickerClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int selectedColor, Integer[] allColors) {
                        //changeBackgroundColor(selectedColor);
                        editorU.putString("textcolor", Integer.toHexString(selectedColor));
                        editorU.commit();

                    }
                })
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                })
                .build()
                .show();

    }

    private void fontspinnermethod() {
        spinerAdapter adapter = new spinerAdapter(this,pictures);
        fontSpinner.setAdapter(adapter);
        fontSpinner.setSelection(shared.getInt("font",0));
        fontSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
               // Toast.makeText(SettingActivity.this, parent.getSelectedItemPosition(), Toast.LENGTH_SHORT).show();
                editorU.putInt("font",parent.getSelectedItemPosition());
                editorU.commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void fontSizespinnermethod() {
        themeadapter adp = new themeadapter(this,size);
        fontSizeSpinner.setAdapter(adp);
        fontSizeSpinner.setSelection(shared.getInt("fontsize",0));
        fontSizeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Toast.makeText(SettingActivity.this, parent.getSelectedItemPosition(), Toast.LENGTH_SHORT).show();
                editorU.putInt("fontsize",parent.getSelectedItemPosition());
                editorU.commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void themeSpinner() {
        ArrayAdapter<String> adapterr = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,themes);
        adapterr.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        themeSpinner.setAdapter(adapterr);
        themeSpinner.setSelection(shared.getInt("selectedtheme",0));

      themeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
          @Override
          public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
              editorU.putInt("selectedtheme",position);
              editorU.commit();

          }

          @Override
          public void onNothingSelected(AdapterView<?> parent) {

          }
      });
    }

  /*  private void changeBackgroundColor(int selectedColor) {
        currentBackgroundColor = selectedColor;
        root.setBackgroundColor(selectedColor);
    }*/

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}

