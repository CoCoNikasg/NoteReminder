package com.example.kyle.reminder;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;

import io.paperdb.Paper;

/**
 * Created by Zahra on 6/10/2019.
 */

public class PatternScreen extends AppCompatActivity {

    SharedPreferences shared;
    SharedPreferences sharedd;
    SharedPreferences.Editor editorU ;
    String final_pattern;
    String save_pattern_key = "pattern_code";
    PatternLockView mPatternLockView;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        shared = this.getSharedPreferences("lockPattern", MODE_PRIVATE);
        editorU = shared.edit();
        Paper.init(this);
         final_pattern= shared.getString("finalPattern", null);
        final String save_pattern = Paper.book().read(save_pattern_key);
        // final String save_pattern = Paper.book().read(shared.getString("savePatternKey", null));
        sharedd = this.getSharedPreferences("fonts", MODE_PRIVATE);
        if (sharedd.getInt("selectedtheme", 0) == 0 ){
            getTheme().applyStyle(R.style.AppTheme,true);
        } else  if (sharedd.getInt("selectedtheme", 0) ==1 ) {
            getTheme().applyStyle(R.style.greenTheme,true);
        } else {
            getTheme().applyStyle(R.style.violetTheme,true);
        }



        if (save_pattern != null){
            setContentView(R.layout.pattern_screen);
            mPatternLockView = findViewById(R.id.pattern_lock_view2);
            patternSize();
            mPatternLockView.addPatternLockListener(new PatternLockViewListener() {
                @Override
                public void onStarted() {

                }

                @Override
                public void onProgress(List<PatternLockView.Dot> progressPattern) {

                }

                @Override
                public void onComplete(List<PatternLockView.Dot> pattern) {
                    final_pattern = PatternLockUtils.patternToString(mPatternLockView,pattern);
                    if (final_pattern.equals(save_pattern)){
                        startActivity(new Intent(PatternScreen.this,MainActivity.class));
                        PatternScreen.this.finish();

                    }else
                        Toast.makeText(PatternScreen.this, "Your password is incorrect", Toast.LENGTH_SHORT).show();

                }

                @Override
                public void onCleared() {

                }
            });

        }
        else {
            startActivity(new Intent(PatternScreen.this,MainActivity.class));
            PatternScreen.this.finish();

        }


    }

    public void patternSize(){
        int w = DisplayMetrics.get_w(PatternScreen.this);
        int h = DisplayMetrics.get_h(PatternScreen.this);

        LinearLayout.LayoutParams f2_1=new LinearLayout.LayoutParams(3*w/4,3*w/4);
        mPatternLockView.setLayoutParams(f2_1);
    }
}
