package com.example.kyle.reminder.checklist.activities;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import androidx.annotation.ColorInt;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.example.kyle.reminder.R;
import com.example.kyle.reminder.checklist.helpers.TinyListSQLHelper;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.thebluealliance.spectrum.SpectrumDialog;

import java.util.Calendar;

import butterknife.BindView;
import butterknife.ButterKnife;

import com.example.kyle.reminder.checklist.adapters.ItemListAdapter;

import com.example.kyle.reminder.checklist.models.Task;
import com.example.kyle.reminder.checklist.models.TaskList;


public class EditListActivity extends AppCompatActivity {


    public static final String INTENT_EDIT = "INTENT_EDIT";
    @BindView(R.id.main_layout)
    LinearLayout mainLayout;
    @BindView(R.id.et_task_list_title)
    EditText etTaskTitle;
    @BindView(R.id.list_item_recyclerview)
    RecyclerView listItemRecyclerview;
    @BindView(R.id.add_item)
    Button addItem;
    private int selectedColor;
    private TaskList editingTaskList;
    private String  id_user = "ca-app-pub-6981902959406280/3788848496";
    private InterstitialAd mInterstitialAd;
    SharedPreferences shared;
    SharedPreferences.Editor editorU;
    public  int error=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        shared = this.getSharedPreferences("fonts", MODE_PRIVATE);
        editorU = shared.edit();
        if (shared.getInt("selectedtheme", 0) == 0 ){
            getTheme().applyStyle(R.style.AppTheme,true);
        } else  if (shared.getInt("selectedtheme", 0) ==1 ) {
            getTheme().applyStyle(R.style.greenTheme,true);
        } else {
            getTheme().applyStyle(R.style.violetTheme,true);
        }


        super.onCreate(savedInstanceState);
        setContentView(R.layout.todo_activity_edit_list);
        shared = this.getSharedPreferences("fonts", MODE_PRIVATE);

        /* Getting the TaskList to edit */
        if (getIntent().getExtras() != null) {
            this.editingTaskList = (TaskList) getIntent().getSerializableExtra(INTENT_EDIT);
        }

        setupViews();
        setListeners();

        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId(id_user);
        mInterstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {

                error=0;

            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                error=1;

            }

            @Override
            public void onAdOpened() {
                // Code to be executed when the ad is displayed.
            }

            @Override
            public void onAdLeftApplication() {
                // Code to be executed when the user has left the app.
            }

            @Override
            public void onAdClosed() {
                if (shared.getInt("ads", 0) == 0 )
                {
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                }
            }
        });

        if (shared.getInt("ads", 0) == 0 )
        {
           mInterstitialAd.loadAd(new AdRequest.Builder().build());
        }
    }


    private void setupViews() {
        ButterKnife.bind(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(false);



        getSupportActionBar().setTitle(R.string.new_shopping_list);

        this.listItemRecyclerview.setLayoutManager(new LinearLayoutManager(this));
        RecyclerView.Adapter mAdapter;
        if (this.editingTaskList == null) {
            mAdapter = new ItemListAdapter(this);
            this.listItemRecyclerview.setAdapter(mAdapter);
            this.selectedColor = Color.parseColor("#FFFFFF");
        } else {
            mAdapter = new ItemListAdapter(editingTaskList.getTasks(), this);
            this.listItemRecyclerview.setAdapter(mAdapter);
            this.selectedColor = this.editingTaskList.getBackgroundColor();
            this.etTaskTitle.setText(this.editingTaskList.getTitle());
            this.mainLayout.setBackgroundColor(this.selectedColor);
            getSupportActionBar().setTitle(this.etTaskTitle.getText().toString());
        }

    }

    private void setListeners() {
        this.etTaskTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                /* Updating activity title as the user writes TaskList title. */
                getSupportActionBar().setTitle(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        this.addItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* Adding new task, scrolling and focusing it.*/
                if (editingTaskList == null)
                    ((ItemListAdapter) listItemRecyclerview.getAdapter()).addItem(new Task());
                else
                    ((ItemListAdapter) listItemRecyclerview.getAdapter()).addItem(new Task(editingTaskList.getTask_list_id()));
                listItemRecyclerview.scrollToPosition(listItemRecyclerview.getAdapter().getItemCount() - 1);
                ((ItemListAdapter) listItemRecyclerview.getAdapter()).setFocusedItem(listItemRecyclerview.getAdapter().getItemCount() - 1);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.edit_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            case R.id.action_palette:
                handlePaletteAction();
                return true;
            case R.id.action_done:
                saveTaskList();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


    private void handlePaletteAction() {
        new SpectrumDialog.Builder(this)
                .setColors(R.array.card_colors)
                .setSelectedColor(this.selectedColor)
                .setDismissOnColorSelected(true)
                .setOnColorSelectedListener(new SpectrumDialog.OnColorSelectedListener() {
                    @Override
                    public void onColorSelected(boolean positiveResult, @ColorInt int color) {
                        if (positiveResult) {
                            selectedColor = color;
                            mainLayout.setBackgroundColor(selectedColor);
                        }

                    }
                }).build().show(getSupportFragmentManager(), "SpectrumDialog");
    }

    private void saveTaskList() {
        if (this.editingTaskList == null) {
            TinyListSQLHelper.getSqlHelper(this).addOrUpdateTaskList(
                    new TaskList(-1, this.etTaskTitle.getText().toString(), Calendar.getInstance().getTime(),
                            ((ItemListAdapter) listItemRecyclerview.getAdapter()).getTasks(), this.selectedColor, false)
            );
        } else {
            this.editingTaskList.setTasks(((ItemListAdapter) listItemRecyclerview.getAdapter()).getTasks());
            this.editingTaskList.setBackgroundColor(this.selectedColor);
            this.editingTaskList.setCreationDate(Calendar.getInstance().getTime());
            this.editingTaskList.setTitle(this.etTaskTitle.getText().toString());
            TinyListSQLHelper.getSqlHelper(this).addOrUpdateTaskList(this.editingTaskList);
        }
        if (shared.getInt("ads", 0) == 0 )
        {

            if (mInterstitialAd.isLoaded()) {

                mInterstitialAd.show();
            }
            else if (error==1)
            {
                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }

        }
        onBackPressed();
    }

}
