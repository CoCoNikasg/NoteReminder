package com.example.kyle.reminder;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;


public class LangSpinner extends AppCompatActivity {
    android.widget.Spinner langSpinner;
    String[] language = {"English","French","Germany"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lang_spinner);
        langSpinner = findViewById(R.id.langSpinner);
        LanguageSpinner();
    }

    private void LanguageSpinner() {
        ArrayAdapter<String> adpp = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,language);
        adpp.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        langSpinner.setAdapter(adpp);


    }
}
