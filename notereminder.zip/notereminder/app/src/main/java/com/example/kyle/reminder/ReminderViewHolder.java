package com.example.kyle.reminder;

import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bignerdranch.android.multiselector.MultiSelector;
import com.bignerdranch.android.multiselector.SwappingHolder;

import java.util.List;

import static com.example.kyle.reminder.ReminderFragment.cxx;


public class ReminderViewHolder extends SwappingHolder implements
                                                       View.OnClickListener,
                                                       View.OnLongClickListener
                                                       {
  private TextView mTitle;
  private TextView mContent;
  private TextView mTime;
  private ImageView mIcon ;
  private ImageView  imageViewShare;




  interface OnClickListener {
        void onClick(ReminderViewHolder holder);
    }

  interface OnLongClickListener {
    boolean onLongClick(ReminderViewHolder holder);
  }

  private OnClickListener mOnClickListener;
  private OnLongClickListener mOnLongClickListener;


  public ReminderViewHolder(View view, MultiSelector multiSelector) {
    super(view, multiSelector);
    view.setOnClickListener(this);
    view.setOnLongClickListener(this);


    mTitle = view.findViewById(R.id.title);
    mContent = view.findViewById(R.id.reminder);
    mTime = view.findViewById(R.id.timeLabel);
    mIcon = view.findViewById(R.id.icon);
    imageViewShare =view.findViewById(R.id.shareRem);



    setSelectionModeBackgroundDrawable(null);
    setSelectionModeStateListAnimator(null);
  }

  public void setTitle(String title) {
    mTitle.setText(title);
  }

  public void setContent(String content) {
    mContent.setText(content);
  }

  public TextView getmContent() {
    return mContent;
  }

  public void setTimeLabel(String timeLabel) {
    if (timeLabel != null) {
      mTime.setText(timeLabel);
      mTime.setVisibility(View.VISIBLE);
    } else {
      mTime.setVisibility(View.GONE);
    }
  }

  public void click_share(final Context cx, final int po, final  List<ReminderItem> mReminderItems)
  {
    imageViewShare.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {

            try
            {
              ReminderItem item = mReminderItems.get(po);
              String share = item.getContent();
              Intent intent = new Intent(Intent.ACTION_SEND);
              intent.setType("text/plain");
              intent.putExtra(Intent.EXTRA_TEXT,share);
              cxx.startActivity(Intent.createChooser(intent, "Share using?"));

            }
            catch (Exception ex)
            {
              Intent intent = new Intent(Intent.ACTION_SEND);
              intent.setType("text/plain");
              intent.putExtra(Intent.EXTRA_TEXT,"");
              cxx.startActivity(Intent.createChooser(intent, "Share using?"));
            }

          }
      });
  }

  public void setIcon(int resId) {
    if (resId != 0) {
      mIcon.setImageResource(resId);
      mIcon.setVisibility(View.VISIBLE);
    } else {
      mIcon.setVisibility(View.GONE);
    }
  }

  public void setOnClickListener(OnClickListener l) {
    mOnClickListener = l;
  }

  public void setOnLongClickListener(OnLongClickListener l) {
    mOnLongClickListener = l;
  }
  @Override
  public boolean onLongClick(View view) {
    if (mOnLongClickListener != null) {
      return mOnLongClickListener.onLongClick(this);
    }
    return false;
  }

  @Override
  public void onClick(View view) {
    if (mOnClickListener != null) {
      mOnClickListener.onClick(this);
    }
  }

  public void setSelected(boolean selected) {

  }

}