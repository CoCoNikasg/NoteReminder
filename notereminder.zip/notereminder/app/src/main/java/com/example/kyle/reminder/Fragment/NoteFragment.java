package com.example.kyle.reminder.Fragment;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.kyle.reminder.R;

import com.example.kyle.reminder.ReminderFragment;
import com.example.kyle.reminder.ReminderParams;
import com.example.kyle.reminder.ReminderType;

public class NoteFragment extends Fragment {

    View v;
    private FragmentManager mFragmentManager;

    public NoteFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_note, container, false);
        mFragmentManager = getActivity().getSupportFragmentManager();

        Bundle args = new Bundle();
        args.putSerializable(ReminderParams.TYPE, ReminderType.NOTE);
        Fragment reminderFragment = new ReminderFragment();
        reminderFragment.setArguments(args);
        mFragmentManager.beginTransaction().add(R.id.content_fram, reminderFragment).commit();


        return v;
    }

}
