package com.example.kyle.reminder;


public class ReminderParams {

  public static final String ID = "_id";
  public static final String TYPE = "type";
  public static final String TITLE = "title";
  public static final String CONTENT = "content";
  public static final String TIME = "time";
  public static final String FREQUENCY = "frequency";
}
