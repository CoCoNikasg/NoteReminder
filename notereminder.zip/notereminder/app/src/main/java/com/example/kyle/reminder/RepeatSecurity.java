package com.example.kyle.reminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;

import io.paperdb.Paper;

public class RepeatSecurity extends AppCompatActivity {

    SharedPreferences shared , sharedd;
    SharedPreferences.Editor editorU ;
    Toolbar toolbaar;
    String save_pattern_key = "pattern_code";
    String final_pattern ;
    int patternsize=0 ;
    PatternLockView mPatternLockView;
    Context context;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Paper.init(this);
        final String save_pattern = Paper.book().read(save_pattern_key);
        shared = this.getSharedPreferences("lockPattern", MODE_PRIVATE);
        editorU = shared.edit();

        sharedd = this.getSharedPreferences("fonts", MODE_PRIVATE);
        if (sharedd.getInt("selectedtheme", 0) == 0 ){
            getTheme().applyStyle(R.style.AppTheme,true);
        } else  if (sharedd.getInt("selectedtheme", 0) ==1 ) {
            getTheme().applyStyle(R.style.greenTheme,true);
        } else {
            getTheme().applyStyle(R.style.violetTheme,true);
        }

        setContentView(R.layout.activity_repeat_security);
        mPatternLockView = findViewById(R.id.pattern_lock_view);
        patternSize();

        mPatternLockView.addPatternLockListener(new PatternLockViewListener() {
                @Override
                public void onStarted() {

                }

                @Override
                public void onProgress(List<PatternLockView.Dot> progressPattern) {

                }

                @Override
                public void onComplete(List<PatternLockView.Dot> pattern) {
                    final_pattern = PatternLockUtils.patternToString(mPatternLockView,pattern);
                    patternsize=pattern.size();
                }

                @Override
                public void onCleared() {

                }
            });



            Button btn_confirm = findViewById(R.id.btn_confirm);
        btn_confirm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String lastpattern = shared.getString("finalPatternn", null);
                    if (lastpattern.equals(final_pattern)){
                        //  Toast.makeText(PatternScreen.this, "correct", Toast.LENGTH_SHORT).show();
                       Paper.book().write(save_pattern_key, final_pattern);
                        editorU.putString("finalPattern", final_pattern);
                        editorU.putString("savePatternKey", save_pattern_key);
                        editorU.commit();
                        finish();


                        AlarmManager alm = (AlarmManager)RepeatSecurity.this.getSystemService(Context.ALARM_SERVICE);
                        alm.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, PendingIntent.getActivity(RepeatSecurity.this, 0, new Intent(RepeatSecurity.this, splash.class), 0));
                        android.os.Process.killProcess(android.os.Process.myPid());

                    }else
                        Toast.makeText(RepeatSecurity.this, getString(R.string.match_patterns), Toast.LENGTH_SHORT).show();

                }
            });




        toolbaar = findViewById(R.id.toolbaar);
        setSupportActionBar(toolbaar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbaar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
    public void patternSize(){
        int w = DisplayMetrics.get_w(RepeatSecurity.this);
        int h = DisplayMetrics.get_h(RepeatSecurity.this);

        LinearLayout.LayoutParams f2_1=new LinearLayout.LayoutParams(3*w/4,3*w/4);
        mPatternLockView.setLayoutParams(f2_1);
    }

}


