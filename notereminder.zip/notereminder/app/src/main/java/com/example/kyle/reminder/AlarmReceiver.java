package com.example.kyle.reminder;

import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.TaskStackBuilder;
import androidx.core.content.ContextCompat;
import androidx.legacy.content.WakefulBroadcastReceiver;
import java.util.Calendar;


public class AlarmReceiver extends WakefulBroadcastReceiver {

  private static final int HOURLY = 1, DAILY = 2, WEEKLY = 3, MONTHLY = 4, YEARLY = 5;

  private Dialog dialog;
  @RequiresApi(api = Build.VERSION_CODES.O)
  @Override
  public void onReceive(Context context, Intent intent) {
    int id = intent.getIntExtra(ReminderParams.ID, -1);
    String title = intent.getStringExtra(ReminderParams.TITLE);
    String msg = intent.getStringExtra(ReminderParams.CONTENT);
    String time1 = intent.getStringExtra(ReminderParams.TIME);

    if (context == null) {
      return;
    }

    ContentResolver contentResolver = context.getContentResolver();
    if (contentResolver == null) {
      return;
    }

    Uri uri = ContentUris.withAppendedId(ReminderContract.All.CONTENT_URI, id);
    Cursor cursor = contentResolver.query(uri,
            null, null, null, null);

    if (cursor == null || !cursor.moveToFirst()) {
      return;
    }

    int frequency = cursor.getInt(cursor.getColumnIndex(ReminderParams.FREQUENCY));
    Calendar time = Calendar.getInstance();
    time.setTimeInMillis(cursor.getLong(cursor.getColumnIndex(ReminderParams.TIME)));
    cursor.close();

    if (frequency > 0) {
      if (frequency == HOURLY) {
        time.add(Calendar.HOUR, 1);

      } else if (frequency == DAILY) {
        time.add(Calendar.DATE, 1);

      } else if (frequency == WEEKLY) {
        time.add(Calendar.DATE, 7);
      } else if (frequency == MONTHLY) {
        time.add(Calendar.MONTH, 1);

      } else if (frequency == YEARLY) {
        time.add(Calendar.YEAR, 1);

      }

      ContentValues values = new ContentValues();
      values.put(com.example.kyle.reminder.ReminderContract.Alerts.TIME, time.getTimeInMillis());
      uri = ContentUris.withAppendedId(com.example.kyle.reminder.ReminderContract.Alerts.CONTENT_URI, id);
      context.getContentResolver().update(uri, values, null, null);

      Intent setAlarm = new Intent(context, com.example.kyle.reminder.AlarmService.class);
      setAlarm.putExtra(ReminderParams.ID, id);
      setAlarm.setAction(com.example.kyle.reminder.AlarmService.CREATE);
      context.startService(setAlarm);
    }


    ////////////////////////Notification

    NotificationManager mNotifyManager =(NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    String id1 = "my_channel_01";
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {


      NotificationChannel channel = new NotificationChannel(id1,
              "Note reminder",
              NotificationManager.IMPORTANCE_DEFAULT);
      mNotifyManager.createNotificationChannel(channel);
    }


    NotificationCompat.Builder mBuilder =
            new NotificationCompat.Builder(context)
                    .setSmallIcon(getNotificationIcon())
                    .setLargeIcon(BitmapFactory.decodeResource(context.getResources(), R.drawable.coconoteicon))
                    .setContentTitle(title)
                    .setChannelId(id1)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(msg))
                    .setColorized(true)
                    .setContentText(msg)
                    .setAutoCancel(true)
                    .setColor(ContextCompat.getColor(context, R.color.colorPrimary))
                    .setPriority(Notification.PRIORITY_HIGH)
                    .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                    // .setOngoing(false)
                    .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));


    Intent notificationIntent = new Intent(context, MainActivity.class);
    notificationIntent.putExtra("started_from","notification");
    TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
    stackBuilder.addParentStack(MainActivity.class);
    stackBuilder.addNextIntent(notificationIntent);
    PendingIntent resultPendingIntent =
            stackBuilder.getPendingIntent(
                    0,
                    PendingIntent.FLAG_UPDATE_CURRENT
            );
    mBuilder.setContentIntent(resultPendingIntent);
    mBuilder.getNotification().flags |= Notification.FLAG_AUTO_CANCEL;
    mNotifyManager.notify(1, mBuilder.build());


    /////////////////////////////////alert dialog widget

    /*int LAYOUT_FLAG;
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
    } else {
      LAYOUT_FLAG = WindowManager.LayoutParams.TYPE_PHONE;
    }


    LayoutInflater layoutInflater = LayoutInflater.from(context);
    View promptsView = layoutInflater.inflate(R.layout.fragment_overlay, null);
    Button remove = (Button) promptsView.findViewById(R.id.remove);
    TextView title1 = (TextView) promptsView.findViewById(R.id.title);
    TextView msg1 = (TextView) promptsView.findViewById(R.id.msg);

    title1.setText(title);
    msg1.setText(msg);


    dialog = new Dialog(context, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
    dialog.setCanceledOnTouchOutside(false);
    dialog.setCancelable(false);
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

    dialog.getWindow().setType(LAYOUT_FLAG);
    dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,270);
    dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
    dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
    dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
    dialog.setContentView(promptsView);
    dialog.getWindow().setGravity(Gravity.CENTER);

    remove.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {

        dialog.dismiss();

      }
    });

    dialog.show();*/


  }


  private int getNotificationIcon() {
    boolean useWhiteIcon = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP);
    return useWhiteIcon ? R.mipmap.ic_launcher : R.mipmap.ic_launcher;
  }


}
