package com.example.kyle.reminder;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;


import com.bignerdranch.android.multiselector.MultiSelector;

import java.util.ArrayList;
import java.util.List;


public class ReminderAdapter extends RecyclerView.Adapter<ReminderViewHolder> implements Filterable {


  private MultiSelector mMultiSelector;
  private ReminderViewHolder.OnClickListener mOnClickListener;
  private ReminderViewHolder.OnLongClickListener mOnLongClickListener;
  private List<ReminderItem> mReminderItems;
  private List<ReminderItem> mReminderItemsfull;
  public  Context context;


  public ReminderAdapter(List<ReminderItem> items,
                         ReminderViewHolder.OnClickListener clickListener,
                         ReminderViewHolder.OnLongClickListener longClickListener) {
    mReminderItems = items;
    mReminderItemsfull = new ArrayList<>(items);
    mOnClickListener = clickListener;
    mOnLongClickListener = longClickListener;
  }

  @Override
  public ReminderViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    context = parent.getContext();
    LayoutInflater inflater = LayoutInflater.from(context);

    View reminderView = inflater.inflate(R.layout.list_item_layout, parent, false);
    return new ReminderViewHolder(reminderView, mMultiSelector);
  }



  @Override
  public void onBindViewHolder(ReminderViewHolder viewHolder, int position) {
    ReminderItem item = mReminderItems.get(position);

    if (item == null) {
      return;
    }
    if (item.getType().equals(ReminderType.ALERT)) {
      viewHolder.setTimeLabel(item.getFormattedTime());
      viewHolder.setIcon(R.drawable.ic_access_alarm_black_24dp);
    } else {
      viewHolder.setTimeLabel(null);
      viewHolder.setIcon(0);
    }
    viewHolder.setTitle(item.getTitle());

    viewHolder.setContent(item.getContent());
    viewHolder.setOnClickListener(mOnClickListener);
    viewHolder.setOnLongClickListener(mOnLongClickListener);
    viewHolder.setSelected(mMultiSelector.isSelected(position, 0));
    viewHolder.click_share(context,position,mReminderItems);

  }


  public int getItemCount() {
    return mReminderItems.size();
  }

  public void setMultiSelector(MultiSelector l) {
    mMultiSelector = l;
  }

  @Override
  public long getItemId(int position){
    return (long) mReminderItems.get(position).getId();
  }

  public ReminderItem getItemAtPosition(int position) {
    return mReminderItems.get(position);
  }


  @Override
  public Filter getFilter() {
    return exampleFilter;
  }

  private Filter exampleFilter = new Filter() {
    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
List<ReminderItem> filteredList = new ArrayList<>();
      if (constraint==null || constraint.length()==0){
        filteredList.addAll(mReminderItemsfull);
      }else {
        String filterPattern = constraint.toString().toLowerCase().trim();

        for (ReminderItem item : mReminderItemsfull){
          if (item.getContent().toLowerCase().contains(filterPattern)){
            filteredList.add(item);
          }
        }
      }
      FilterResults results = new FilterResults();
      results.values = filteredList;
      return  results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
mReminderItems.clear();
      mReminderItems.addAll((List)results.values);
      notifyDataSetChanged();
    }
  };



}


