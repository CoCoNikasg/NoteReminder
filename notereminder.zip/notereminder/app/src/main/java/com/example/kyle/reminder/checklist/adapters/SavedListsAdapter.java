package com.example.kyle.reminder.checklist.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.example.kyle.reminder.R;
import com.example.kyle.reminder.checklist.activities.EditListActivity;
import com.example.kyle.reminder.checklist.helpers.TinyListSQLHelper;
import com.example.kyle.reminder.checklist.models.Task;
import com.example.kyle.reminder.checklist.models.TaskList;
import com.example.kyle.reminder.font.TextviewFont;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;


public class SavedListsAdapter extends RecyclerView.Adapter<SavedListsAdapter.ViewHolder>  {

    private ArrayList<TaskList> taskLists;
    private final Context context;
    @SuppressLint("SimpleDateFormat")
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    /* Cached item to restore (if user wants to), used when an item is removed. */
    private TaskList cachedItem;
    private int contextMenuSelectedPosition;

    public SavedListsAdapter(ArrayList<TaskList> taskLists, Context context) {
        this.taskLists = taskLists;
        this.context = context;

    }

    public void updateList(ArrayList<TaskList> list){
        taskLists = list;
        notifyDataSetChanged();
    }

    @Override
    public SavedListsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new SavedListsAdapter.ViewHolder(
                LayoutInflater.from(parent.getContext()).inflate(R.layout.todo_saved_list_cardview, parent, false));
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        TaskList item = taskLists.get(position);
        if (item == null) {
            return;
        }
        holder.cardView.setCardBackgroundColor(taskLists.get(holder.getAdapterPosition()).getBackgroundColor());
        holder.taskListTitle.setVisibility(View.VISIBLE);
        if (taskLists.get(holder.getAdapterPosition()).getTitle().isEmpty())
            holder.taskListTitle.setVisibility(View.GONE);
        else
            holder.taskListTitle.setText(taskLists.get(holder.getAdapterPosition()).getTitle());

        holder.taskContainer.removeAllViews();
        for (Task task : taskLists.get(holder.getAdapterPosition()).getTasks()) {
            TextviewFont taskDescription = new TextviewFont(context);
            taskDescription.setText(task.getTask());
            taskDescription.setTextSize(18f);
            if (task.isChecked()) {
                taskDescription.setPaintFlags(taskDescription.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                taskDescription.setAlpha(0.3f);
            }
            holder.taskContainer.addView(taskDescription);
        }
        holder.taskListDate.setText(dateFormat.format(taskLists.get(holder.getAdapterPosition()).getCreationDate()));
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EditListActivity.class);
                intent.putExtra(EditListActivity.INTENT_EDIT, taskLists.get(holder.getAdapterPosition()));
                context.startActivity(intent);
            }
        });
        holder.cardView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
               // setContextMenuSelectedPosition(holder.getAdapterPosition());
                new MaterialDialog.Builder(context)
                        .positiveText(android.R.string.ok)
                        .onPositive(new MaterialDialog.SingleButtonCallback() {
                            @Override
                            public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                                TinyListSQLHelper.getSqlHelper(context).deleteTaskList(taskLists.get(holder.getAdapterPosition()).getTask_list_id());
                                removeItem(holder.getAdapterPosition());
                            }
                        })
                        .negativeText(android.R.string.cancel)
                        .title(context.getString(R.string.delete_title) + taskLists.get(holder.getAdapterPosition()).getTitle())
                        .content(context.getString(R.string.delete_msg_1) + taskLists.get(holder.getAdapterPosition()).getTitle() + context.getString(R.string.delete_msg_2))
                        .show();
                return false;
            }
        });
        holder.archiveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final TaskList taskListToArchive = taskLists.get(holder.getAdapterPosition());
                taskListToArchive.setIsArchived(true);
                TinyListSQLHelper.getSqlHelper(context).addOrUpdateTaskList(taskListToArchive);
                removeItem(holder.getAdapterPosition());
                //  ((SavedListsFragment) ((MainActivity) context).getCurrentVisibleFragment()).undoSnackbar();
            }
        });
        holder.shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String shareIntentText = "";
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntentText += taskLists.get(holder.getAdapterPosition()).getTitle() + "\n\n";
                for (Task task : taskLists.get(holder.getAdapterPosition()).getTasks()) {
                    shareIntentText += (task.isChecked() ? Task.DONE_TASK_MARK : Task.UNDONE_TASK_MARK)
                            + " " + task.getTask() + "\n";
                }
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareIntentText.trim());
                context.startActivity(Intent.createChooser(shareIntent, context.getString(R.string.share_with)));
            }
        });
    }

    @Override
    public int getItemCount() {
        return this.taskLists.size();
    }

    public void removeItem(int position) {
        this.cachedItem = this.taskLists.get(position);
        this.taskLists.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, getItemCount() - position);
    }


    public void replaceWith(ArrayList<TaskList> newTaskLists) {
        this.taskLists.clear();
        this.taskLists.addAll(newTaskLists);
        notifyDataSetChanged();
    }

    public TaskList getItem(int position) {
        return this.taskLists.get(position);
    }

    public TaskList getCachedItem() {
        return this.cachedItem;
    }


    public void setCachedItem(TaskList item) {
        this.cachedItem = item;
    }

    public int getContextMenuSelectedPosition() {
        return contextMenuSelectedPosition;
    }

    public void setContextMenuSelectedPosition(int contextMenuSelectedPosition) {
        this.contextMenuSelectedPosition = contextMenuSelectedPosition;
    }

    @Override
    public void onViewRecycled(ViewHolder holder) {
        holder.cardView.setOnLongClickListener(null);
        super.onViewRecycled(holder);
    }


    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnCreateContextMenuListener {

        @BindView(R.id.task_list_title)
        TextView taskListTitle;
        @BindView(R.id.task_container)
        LinearLayout taskContainer;
        @BindView(R.id.task_list_date)
        TextView taskListDate;
        @BindView(R.id.card_view_saved_lists)
        CardView cardView;
        @BindView(R.id.archive)
        ImageView archiveButton;
        @BindView(R.id.share)
        ImageView shareButton;

        public ViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
            itemView.setOnCreateContextMenuListener(this);
        }

        @Override
        public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
           // contextMenu.add(Menu.NONE, R.id.contextual_delete_menu, Menu.NONE, R.string.delete_list_cont_menu);
        }
    }



}
