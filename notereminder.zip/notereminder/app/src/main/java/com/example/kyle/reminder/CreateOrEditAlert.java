package com.example.kyle.reminder;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import androidx.annotation.NonNull;
import androidx.core.app.NavUtils;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TimePicker;


import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.github.javiersantos.materialstyleddialogs.MaterialStyledDialog;
import com.github.javiersantos.materialstyleddialogs.enums.Style;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class CreateOrEditAlert extends AppCompatActivity {
  private SimpleAdapter mAdapter;
  private EditText mContent, mTitle;
  private String mTime, mDate;
  private int mRepeatMode;
  private Map<String, String> mAlarmTime, mAlarmDate, mAlarmRepeat;
  private Calendar mAlertTime;
  private ContentResolver mContentResolver;
  private ReminderItem mData;

  private static final String NONE = "None";
  private static final String HOURLY = "Hourly";
  private static final String DAILY = "Daily";
  private static final String WEEKLY = "Weekly";
  private static final String MONTHLY = "Monthly";
  private static final String YEARLY = "Yearly";

  private static final String[] REPEAT_MODES =
          new String[]{NONE, HOURLY, DAILY, WEEKLY, MONTHLY, YEARLY};

  private static final DateFormat TIME_FORMAT = new SimpleDateFormat("hh:mm aa", Locale.CANADA);
  private static final DateFormat DATE_FORMAT = new SimpleDateFormat("dd/MM/yy", Locale.CANADA);

  private static final String ITEM_TITLE = "header";
  private static final String ITEM_CONTENT = "content";

  private static final String TIME_SETTING = "Time";
  private static final String DATE_SETTING = "Date";
  private static final String REPEAT_SETTING = "Repeat";

  private static final int TIME_POSITION = 0;
  private static final int DATE_POSITION = 1;
  private static final int REPEAT_POSITION = 2;
  private final int REQ_CODE_SPEECH_INPUT = 242;
  private ImageView voice_typingAlert;
  private  String matn="";
  private String  id_user = "ca-app-pub-6981902959406280/3788848496";
  private InterstitialAd mInterstitialAd;
  SharedPreferences shared;
  SharedPreferences.Editor editor;
  public  int error=0;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    shared = this.getSharedPreferences("fonts", MODE_PRIVATE);
    editor = shared.edit();

    if (shared.getInt("selectedtheme", 0) == 0 ){
      getTheme().applyStyle(R.style.AppTheme,true);
    } else  if (shared.getInt("selectedtheme", 0) ==1 ) {
      getTheme().applyStyle(R.style.greenTheme,true);
    } else {
      getTheme().applyStyle(R.style.violetTheme,true);
    }

    setContentView(R.layout.activity_create_or_edit_alert);

    mContentResolver = getContentResolver();

    List<Map<String, String>> mapList = new ArrayList<>();
    mAlarmTime = new HashMap<>();
    mAlarmDate = new HashMap<>();
    mAlarmRepeat = new HashMap<>();

    mContent = findViewById(R.id.alert_content);
    mTitle = findViewById(R.id.alert_title);
    voice_typingAlert = findViewById(R.id.voiceTypingAlert);

    mRepeatMode = 0;

    Intent intent = getIntent();
    mData = intent.getParcelableExtra("data");
    mAlertTime = Calendar.getInstance();

    Toolbar toolbar = findViewById(R.id.tool_baar);
    this.setSupportActionBar(toolbar);
    ActionBar actionBar = getSupportActionBar();


    actionBar.setDisplayHomeAsUpEnabled(false);
    actionBar.setDisplayShowHomeEnabled(false);

    if (mData != null) {
      mTitle.setText(mData.getTitle());
      mContent.setText(mData.getContent());
      mAlertTime.setTimeInMillis(mData.getTimeInMillis());
      mRepeatMode = mData.getFrequency();

      mTime = TIME_FORMAT.format(mAlertTime.getTime());
      mDate = DATE_FORMAT.format(mAlertTime.getTime());
      setActionBarTitle(actionBar, "");
    } else {
      mData = new ReminderItem();
      Calendar current = Calendar.getInstance();
      mTime = TIME_FORMAT.format(current.getTime());
      mDate = DATE_FORMAT.format(current.getTime());
      mAlertTime.setTimeInMillis(current.getTimeInMillis());

      mData.setTimeInMillis(current.getTimeInMillis());
      mData.setFrequency(mRepeatMode);
      setActionBarTitle(actionBar, "");
    }

    mAlarmTime.put(ITEM_TITLE, TIME_SETTING);
    mAlarmTime.put(ITEM_CONTENT, mTime);
    mAlarmDate.put(ITEM_TITLE, DATE_SETTING);
    mAlarmDate.put(ITEM_CONTENT, mDate);
    mAlarmRepeat.put(ITEM_TITLE, REPEAT_SETTING);
    mAlarmRepeat.put(ITEM_CONTENT, REPEAT_MODES[mRepeatMode]);

    mapList.add(mAlarmTime);
    mapList.add(mAlarmDate);
    mapList.add(mAlarmRepeat);

    mAdapter = new SimpleAdapter(this, mapList, android.R.layout.simple_list_item_2,
            new String[]{ITEM_TITLE, ITEM_CONTENT}, new int[]{
        android.R.id.text1, android.R.id.text2});
    ListView listView = findViewById(R.id.alert_settings);
    listView.setAdapter(mAdapter);

    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        switch (i) {
          case TIME_POSITION:
            TimePickerDialog timePicker = getTimePicker();
            timePicker.show();
            break;
          case DATE_POSITION:
            DatePickerDialog datePicker = getDatePicker();
            datePicker.show();
            break;
          case REPEAT_POSITION:
            createRepeatDialog().show();
            break;
          default:
            Log.e(this.getClass().getName(), "Out of bounds setting position.");
            break;
        }
      }
    });

    voice_typingAlert.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        startVoiceInput();
      }
    });

    mContent.setOnFocusChangeListener(new View.OnFocusChangeListener() {
      @Override
      public void onFocusChange(View v, boolean hasFocus) {

        matn=mContent.getText().toString();

      }
    });


    mInterstitialAd = new InterstitialAd(this);
    mInterstitialAd.setAdUnitId(id_user);
    mInterstitialAd.setAdListener(new AdListener() {
      @Override
      public void onAdLoaded() {

        error=0;

      }

      @Override
      public void onAdFailedToLoad(int errorCode) {
        error=1;
      //  Toast.makeText(CreateOrEditAlert.this, errorCode+"", Toast.LENGTH_SHORT).show();
      }

      @Override
      public void onAdOpened() {
        // Code to be executed when the ad is displayed.
      }

      @Override
      public void onAdLeftApplication() {
        // Code to be executed when the user has left the app.
      }

      @Override
      public void onAdClosed() {
        if (shared.getInt("ads", 0) == 0 )
        {
          mInterstitialAd.loadAd(new AdRequest.Builder().build());
        }
      }
    });

    if (shared.getInt("ads", 0) == 0 )
    {
      mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }

  }

  @Override
  public void onBackPressed() {
    promptSave();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.menu_create_or_edit_alert, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.action_save_alert:
      //  createDeleteDialog(mData).show();
     promptSave();
        break;

      case R.id.English:
        editor.putString("lang","en_DE");
        editor.commit();
        break;

      case R.id.French:
        editor.putString("lang","fr_FR");
        editor.commit();
        break;

      case R.id.German:
        editor.putString("lang","de_AT");
        editor.commit();
        break;

      case R.id.Persian:
        editor.putString("lang","fa_IR");
        editor.commit();
        break;

      case R.id.Arabic:
        editor.putString("lang","ar_AE");
        editor.commit();
        break;

      case R.id.Indian:
        editor.putString("lang","hi_IN");
        editor.commit();
        break;

      case R.id.Korean:
        editor.putString("lang","ko_KR");
        editor.commit();
        break;

      case R.id.Italian:
        editor.putString("lang","it_IT");
        editor.commit();
        break;

      case R.id.Spanish:
        editor.putString("lang","es_ES");
        editor.commit();
        break;

      case R.id.PhoneLang:
        editor.putString("lang",Locale.getDefault()+"");
        editor.commit();
        break;

      default:
        break;
    }
    return true;
  }

  private TimePickerDialog getTimePicker() {
    return new TimePickerDialog(CreateOrEditAlert.this, new TimePickerDialog.OnTimeSetListener() {
              @Override
              public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                mAlertTime.set(Calendar.HOUR_OF_DAY, hour);
                mAlertTime.set(Calendar.MINUTE, minute);
                mAlertTime.set(Calendar.SECOND, 0);
                mTime = TIME_FORMAT.format(mAlertTime.getTime());
                mAlarmTime.put(ITEM_CONTENT, mTime);
                mData.setTimeInMillis(mAlertTime.getTimeInMillis());
                mAdapter.notifyDataSetChanged();
              }
            }, mAlertTime.get(Calendar.HOUR_OF_DAY), mAlertTime.get(Calendar.MINUTE), false);
  }

  private DatePickerDialog getDatePicker() {
    DatePickerDialog datePicker = new DatePickerDialog(CreateOrEditAlert.this,
        new DatePickerDialog.OnDateSetListener() {
              @Override
              public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                mAlertTime.set(Calendar.YEAR, year);
                mAlertTime.set(Calendar.MONTH, month);
                mAlertTime.set(Calendar.DAY_OF_MONTH, day);
                mDate = DATE_FORMAT.format(mAlertTime.getTime());
                mAlarmDate.put(ITEM_CONTENT, mDate);
                mData.setTimeInMillis(mAlertTime.getTimeInMillis());
                mAdapter.notifyDataSetChanged();
              }
            }, mAlertTime.get(Calendar.YEAR), mAlertTime.get(Calendar.MONTH),
            mAlertTime.get(Calendar.DAY_OF_MONTH));
    datePicker.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
    return datePicker;
  }

  private void createSaveDialog(final ReminderItem item) {
    new MaterialStyledDialog.Builder(CreateOrEditAlert.this)
            .setDescription(R.string.save_prompt)
            .setStyle(Style.HEADER_WITH_TITLE)
            .setTitle(R.string.confirm)
           // .setIcon(R.drawable.ic_exit_to_app_black_24dp)
            // .setStyle(Style.HEADER_WITH_TITLE)
            .withIconAnimation(true)
            .withDialogAnimation(true)
            //.setHeaderColor(R.color.colorPrimaryDark)
            .setPositiveText(R.string.yes)
            .setNegativeText(R.string.no)
            .setScrollable(true)
            .onPositive(new MaterialDialog.SingleButtonCallback() {
              @Override
              public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                saveAlert(item);
                terminateActivity();
                dialog.dismiss();
                if (shared.getInt("ads", 0) == 0 )
                {

                  if (mInterstitialAd.isLoaded()) {

                    mInterstitialAd.show();
                  }
                  else if (error==1)
                  {
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                  }

                }

              }

            })
            .onNegative(new MaterialDialog.SingleButtonCallback() {
              @Override
              public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                terminateActivity();
                dialog.dismiss();
              }
            })
          .show();


  }

  private AlertDialog createDeleteDialog(final ReminderItem item) {
    return new AlertDialog.Builder(this)
            .setTitle(R.string.confirm)
            .setMessage(R.string.delete_prompt)
            .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
              public void onClick(DialogInterface dialog, int i) {
                deleteAlert(item);
              }
            })
            .setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
              public void onClick(DialogInterface dialog, int i) {
                dialog.dismiss();
              }
            })
            .create();

  }

  private AlertDialog createRepeatDialog() {
    final int prevRepeat = mRepeatMode;
    return new AlertDialog.Builder(this)
            .setTitle(R.string.repeat)
            .setSingleChoiceItems(REPEAT_MODES, 0, new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int i) {
                mRepeatMode = i;
              }
            })
            .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int i) {
                mAlarmRepeat.put(ITEM_CONTENT, REPEAT_MODES[mRepeatMode]);
                mData.setFrequency(mRepeatMode);
                mAdapter.notifyDataSetChanged();
                dialog.dismiss();
              }
            })
            .setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
              @Override
              public void onClick(DialogInterface dialog, int i) {
                mRepeatMode = prevRepeat;
                mData.setFrequency(mRepeatMode);
              }
            })
            .create();
  }

  private void createAlarm(int id) {
    Intent alarm = new Intent(this, AlarmService.class);
    alarm.putExtra(ReminderParams.ID, id);
    alarm.setAction(AlarmService.CREATE);
    startService(alarm);
  }

  private void terminateActivity() {
    NavUtils.navigateUpFromSameTask(this);
  }

  private void promptSave() {
    mData.setTitle(mTitle.getText().toString());
    mData.setContent(mContent.getText().toString());
    createSaveDialog(mData);
  }

  private void setActionBarTitle(ActionBar actionBar, String title) {
    if (actionBar != null) {
      actionBar.setTitle(title);
      actionBar.setDisplayHomeAsUpEnabled(false);
    }
  }

  private void deleteAlert(ReminderItem item) {
    if (item != null) {
      Intent delete = new Intent(CreateOrEditAlert.this, AlarmService.class);
      delete.putExtra(ReminderParams.ID, item.getId());
      delete.setAction(AlarmService.DELETE);
      Uri uri = ContentUris.withAppendedId(ReminderContract.Notes.CONTENT_URI, item.getId());
      mContentResolver.delete(uri, null, null);
      startService(delete);
      terminateActivity();
    } else {
      terminateActivity();
    }
  }

  private void saveAlert(final ReminderItem item) {
    if (item.getId() > 0) {
      Intent cancelPrevious = new Intent(CreateOrEditAlert.this,
          AlarmService.class);
      cancelPrevious.putExtra(ReminderParams.ID, item.getId());
      cancelPrevious.setAction(AlarmService.CANCEL);
      startService(cancelPrevious);
      ContentValues values = new ContentValues();
      values.put(ReminderContract.Alerts.TITLE, item.getTitle());
      values.put(ReminderContract.Alerts.CONTENT, item.getContent());
      values.put(ReminderContract.Alerts.TIME, item.getTimeInMillis());
      values.put(ReminderContract.Alerts.FREQUENCY, item.getFrequency());
      Uri uri = ContentUris.withAppendedId(ReminderContract.Alerts.CONTENT_URI, item.getId());
      mContentResolver.update(uri, values, null, null);
      createAlarm(item.getId());
    } else {
      ContentValues values = new ContentValues();
      values.put(ReminderContract.Alerts.TYPE, ReminderType.ALERT.getName());
      values.put(ReminderContract.Alerts.TITLE, item.getTitle());
      values.put(ReminderContract.Alerts.CONTENT, item.getContent());
      values.put(ReminderContract.Alerts.TIME, item.getTimeInMillis());
      values.put(ReminderContract.Alerts.FREQUENCY, item.getFrequency());
      Uri uri = mContentResolver.insert(ReminderContract.Notes.CONTENT_URI,
          values);
      if (uri != null) {
        createAlarm(Integer.parseInt(uri.getLastPathSegment()));
      }
    }
  }

  private void startVoiceInput() {
    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, shared.getString("lang",null));
    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, R.string.say_someting);
    try {
      startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
    } catch (ActivityNotFoundException a) {

    }
  }


  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);

    switch (requestCode) {
      case REQ_CODE_SPEECH_INPUT: {
        if (resultCode == RESULT_OK && null != data) {
          ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
          matn=mContent.getText().toString();
          matn=matn+" "+result.get(0);
          mContent.setText(matn);
        }
        break;
      }

    }
  }

}
