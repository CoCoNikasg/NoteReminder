package com.example.kyle.reminder.checklist.fragments;


import android.os.Bundle;
import com.google.android.material.snackbar.Snackbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.example.kyle.reminder.R;
import com.example.kyle.reminder.checklist.activities.MainActivity;
import com.example.kyle.reminder.checklist.adapters.SavedListsAdapter;
import com.example.kyle.reminder.checklist.helpers.TinyListSQLHelper;
import com.example.kyle.reminder.checklist.models.TaskList;
import com.example.kyle.reminder.checklist.widgets.FABScrollBehavior;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;


public class SavedListsFragment extends BaseFragment {

    @BindView(R.id.saved_list_recycler_view)
    RecyclerView savedListsRecyclerView;
    ArrayList<TaskList> list;
    private SavedListsAdapter mAdapter;

    public SavedListsFragment() {
        // Required empty public constructor
    }


    public static SavedListsFragment getInstance() {
        return new SavedListsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.todo_fragment_saved_lists, container, false);
        ButterKnife.bind(this, view);

        SearchView searchView = view.findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                filter(s.toLowerCase());
                return false;
            }
        });

        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupViews();
    }

    void filter(String text){
        ArrayList<TaskList> temp = new ArrayList();
        for(TaskList d: list){
            if(d.getTitle().toLowerCase().contains(text)){
                temp.add(d);
            }
        }

        mAdapter.updateList(temp);
    }
    @Override
    void setupViews() {
        savedListsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        list=TinyListSQLHelper.getSqlHelper(getActivity()).getTaskLists(false);
        mAdapter = new SavedListsAdapter(TinyListSQLHelper.getSqlHelper(getActivity()).getTaskLists(false), getActivity());
        savedListsRecyclerView.setAdapter(mAdapter);
        ItemTouchHelper.SimpleCallback simpleItemTouchCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(final RecyclerView.ViewHolder viewHolder, int direction) {
                /* Archiving the swiped item and showing an Snackbar with "UNDO" option. */
                final TaskList taskListToArchive = ((SavedListsAdapter) savedListsRecyclerView.getAdapter()).getItem(viewHolder.getAdapterPosition());
                taskListToArchive.setIsArchived(true);
                TinyListSQLHelper.getSqlHelper(getActivity()).addOrUpdateTaskList(taskListToArchive);
                ((SavedListsAdapter) savedListsRecyclerView.getAdapter()).removeItem(viewHolder.getAdapterPosition());
                undoSnackbar();
            }
        };
        new ItemTouchHelper(simpleItemTouchCallback).attachToRecyclerView(savedListsRecyclerView);
        registerForContextMenu(savedListsRecyclerView);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.contextual_delete_menu) {
            final int position = ((SavedListsAdapter) this.savedListsRecyclerView.getAdapter()).getContextMenuSelectedPosition();
            TinyListSQLHelper.getSqlHelper(getActivity())
                    .deleteTaskList(((SavedListsAdapter) this.savedListsRecyclerView.getAdapter()).getItem(position).getTask_list_id());
            ((SavedListsAdapter) this.savedListsRecyclerView.getAdapter()).removeItem(position);
        }
        return super.onContextItemSelected(item);
    }


    @Override
    public void redrawItems() {
        ((SavedListsAdapter) savedListsRecyclerView.getAdapter()).replaceWith(TinyListSQLHelper.getSqlHelper(getActivity()).getTaskLists(false));
    }


    public void undoSnackbar() {
        Snackbar undoSnackbar = Snackbar
                .make(this.savedListsRecyclerView, R.string.list_archived, Snackbar.LENGTH_LONG)
                .setAction(R.string.undo, new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (((SavedListsAdapter) savedListsRecyclerView.getAdapter()).getCachedItem() != null) {
                            final TaskList taskListToArchive = ((SavedListsAdapter) savedListsRecyclerView.getAdapter()).getCachedItem();
                            taskListToArchive.setIsArchived(false);
                            TinyListSQLHelper.getSqlHelper(getActivity()).addOrUpdateTaskList(taskListToArchive);
                            clearCachedItem();
                            ((MainActivity) getActivity()).getCurrentVisibleFragment().redrawItems();
                        }
                    }
                })

                .addCallback(new Snackbar.Callback() {
                    public void onShown(Snackbar snackbar) {
                        super.onShown(snackbar);
                        FABScrollBehavior.setCanHideChild(false);
                    }

                    @Override
                    public void onDismissed(Snackbar snackbar, int event) {
                        super.onDismissed(snackbar, event);
                        FABScrollBehavior.setCanHideChild(true);
                    }
                });

        undoSnackbar.show();
    }

    public void clearCachedItem() {
        ((SavedListsAdapter) this.savedListsRecyclerView.getAdapter()).setCachedItem(null);
    }

    @Override
    public void onStart() {
        super.onStart();
        /* Redraw items when this fragment is first viewed by the user. */
        redrawItems();
    }

}
