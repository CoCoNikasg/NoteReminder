package com.example.kyle.reminder;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class X extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.custom_spiner_item);
    }
}
