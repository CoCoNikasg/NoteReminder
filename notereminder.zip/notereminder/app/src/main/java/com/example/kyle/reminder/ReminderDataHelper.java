package com.example.kyle.reminder;

import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;

/**
 * Created by zahra on 05/09/18.
 * <p>
 * SQLite database for storing notes/alerts
 */
public class ReminderDataHelper extends SQLiteOpenHelper {

  private static final String DATABASE_NAME = "reminderData.db";
  private static final int DATABASE_VERSION = 1;
  private static final String DB_TABLE_NAME = "reminders";
  private static final String DB_COLUMN_ID = "_id";
  private static final String DB_COLUMN_TYPE = "type";
  private static final String DB_COLUMN_TITLE = "title";
  private static final String DB_COLUMN_CONTENT = "content";
  private static final String DB_COLUMN_TIME = "time";
  private static final String DB_COLUMN_FREQUENCY = "frequency";

  public ReminderDataHelper(Context context) {
    super(context, DATABASE_NAME, null, DATABASE_VERSION);
  }

  @Override
  public void onCreate(SQLiteDatabase db) {
    db.execSQL("CREATE TABLE " + DB_TABLE_NAME + "(" +
            DB_COLUMN_ID + " INTEGER PRIMARY KEY, " +
            DB_COLUMN_TYPE + " TEXT, " +
            DB_COLUMN_TITLE + " TEXT, " +
            DB_COLUMN_CONTENT + " TEXT, " +
            DB_COLUMN_FREQUENCY + " TEXT, " +
            DB_COLUMN_TIME + " LONG)"
    );
  }

  @Override
  public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    db.execSQL("DROP TABLE IF EXISTS " + DB_TABLE_NAME);
    onCreate(db);
  }

  /////////////////////////query widget

  public int getnoteCount() {
    String countQuery = "SELECT  * FROM " + DB_TABLE_NAME + " where type like 'note' ";
    SQLiteDatabase db = this.getReadableDatabase();
    Cursor cursor = db.rawQuery(countQuery, null);
    int count = cursor.getCount();
    cursor.close();
    return count;
  }

  public String select_note(int row, int field)
  {
    String countQuery = "SELECT  * FROM " + DB_TABLE_NAME + " where type like 'note' ";
    SQLiteDatabase db = this.getReadableDatabase();
    Cursor cr = db.rawQuery(countQuery, null);
    String r = "";
    if( cr != null && cr.moveToFirst() ){
      cr.moveToPosition(row);
      r = cr.getString(field);
      cr.close();
    }
    return r;
  }

}
