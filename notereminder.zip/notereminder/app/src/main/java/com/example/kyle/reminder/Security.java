package com.example.kyle.reminder;

import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import android.widget.LinearLayout;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;

import io.paperdb.Paper;

public class Security extends AppCompatActivity {

    SharedPreferences shared , sharedd;
    SharedPreferences.Editor editorU ;
    Toolbar toolbaar;
    String save_pattern_key = "pattern_code";
    String final_pattern ;
    int patternsize=0 ;
    PatternLockView mmPatternLockView;
    Button btn_continue,btn_back;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Paper.init(this);

      // final String save_patternn = Paper.book().read(save_pattern_key);
        shared = this.getSharedPreferences("lockPattern", MODE_PRIVATE);
        editorU = shared.edit();

        sharedd = this.getSharedPreferences("fonts", MODE_PRIVATE);
        if (sharedd.getInt("selectedtheme", 0) == 0 ){
            getTheme().applyStyle(R.style.AppTheme,true);
        } else  if (sharedd.getInt("selectedtheme", 0) ==1 ) {
            getTheme().applyStyle(R.style.greenTheme,true);
        } else {
            getTheme().applyStyle(R.style.violetTheme,true);
        }

        setContentView(R.layout.activity_security);
        btn_back = findViewById(R.id.btn_back);
        btn_continue = findViewById(R.id.btn_continue);
        btn_continue.setEnabled(false);
        btn_continue.setTextColor(getResources().getColor(R.color.secondary_text));
        mmPatternLockView = findViewById(R.id.pattern_lock_view);
        patternSize();
        mmPatternLockView.addPatternLockListener(new PatternLockViewListener() {
                @Override
                public void onStarted() {

                }

                @Override
                public void onProgress(List<PatternLockView.Dot> progressPattern) {

                }

                @Override
                public void onComplete(List<PatternLockView.Dot> pattern) {
                    final_pattern = PatternLockUtils.patternToString(mmPatternLockView,pattern);
                    patternsize=pattern.size();
                    btn_continue.setTextColor(getResources().getColor(R.color.black));
                    btn_continue.setEnabled(true);
                }

                @Override
                public void onCleared() {

                }
            });



        btn_continue.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                        if (patternsize==0){
                            Toast.makeText(Security.this, "please set pattern lock", Toast.LENGTH_SHORT).show();
                        }
                        else{
               //      Paper.book().write(save_pattern_key, final_pattern);
                        editorU.putString("finalPatternn", final_pattern);
                        editorU.putString("savePatternKey", save_pattern_key);
                        editorU.commit();
                        finish();
                        startActivity(new Intent(Security.this,RepeatSecurity.class));
                      }

                }
            });


btn_back.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        onBackPressed();
    }
});

        toolbaar = findViewById(R.id.toolbaar);
        setSupportActionBar(toolbaar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbaar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public void patternSize(){
        int w = DisplayMetrics.get_w(Security.this);
        int h = DisplayMetrics.get_h(Security.this);

        LinearLayout.LayoutParams f2_1=new LinearLayout.LayoutParams(3*w/4,3*w/4);
        mmPatternLockView.setLayoutParams(f2_1);
    }

}


