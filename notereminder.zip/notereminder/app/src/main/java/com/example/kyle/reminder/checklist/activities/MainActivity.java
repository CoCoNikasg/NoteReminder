package com.example.kyle.reminder.checklist.activities;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Environment;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.kyle.reminder.R;
import com.example.kyle.reminder.Security;
import com.example.kyle.reminder.SettingActivity;
import com.example.kyle.reminder.aboutUs;
import com.example.kyle.reminder.checklist.fragments.ArchivedListsFragment;
import com.example.kyle.reminder.checklist.fragments.BaseFragment;
import com.example.kyle.reminder.checklist.fragments.SavedListsFragment;
import com.example.kyle.reminder.contactUs;
import com.example.kyle.reminder.util.IabHelper;
import com.example.kyle.reminder.util.IabResult;
import com.example.kyle.reminder.util.Inventory;
import com.example.kyle.reminder.util.Purchase;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


public class MainActivity extends AppCompatActivity {

    @BindView(R.id.container)
    ViewPager viewPagerContainer;
    @BindView(R.id.fab)
    FloatingActionButton fab;
    @BindView(R.id.toolbar)
    Toolbar toolbar;
    @BindView(R.id.tabs)
    TabLayout tabLayout;
    @BindView(R.id.appbar)
    AppBarLayout appBarLayout;
    SharedPreferences shared;
    SharedPreferences.Editor editorU ;
    private String mActivityTitle;
    private View mNavHeader;
    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;

    private IabHelper bhelper;
    ProgressDialog bar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        shared = this.getSharedPreferences("fonts", MODE_PRIVATE);
        editorU = shared.edit();
        if (shared.getInt("selectedtheme", 0) == 0 ){
            getTheme().applyStyle(R.style.AppTheme,true);
        } else  if (shared.getInt("selectedtheme", 0) ==1 ) {
            getTheme().applyStyle(R.style.greenTheme,true);
        } else {
            getTheme().applyStyle(R.style.violetTheme,true);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.todo_activity_main);

        setupView();
        setListeners();
        setupDrawer();
    }


    private void setupView() {
        ButterKnife.bind(this);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            toolbar.setNavigationIcon(R.drawable.draw);
        }

        viewPagerContainer.setAdapter(new SectionsPagerAdapter(getSupportFragmentManager()));

        tabLayout.setupWithViewPager(viewPagerContainer);
        tabLayout.getTabAt(0).setIcon(R.drawable.sav);
        tabLayout.getTabAt(1).setIcon(R.drawable.archive);
    }

    private void setListeners() {
        /* FAB handling the main action, adding a new TaskList */
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, EditListActivity.class);
                startActivity(intent);
            }
        });
        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (verticalOffset == 0) { //expanded
                    fab.show();
                } else if (Math.abs(verticalOffset) >= appBarLayout.getTotalScrollRange()) { //collapsed
                    fab.hide();
                }
            }
        });
        viewPagerContainer.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                appBarLayout.setExpanded(true, true);
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                /* If the user starts scrolling or dragging the ViewPager, the adapters will redraw
                 * themselves in order to show recent changes. */
                if (state != ViewPager.SCROLL_STATE_IDLE) {
                    try {
                        ((SectionsPagerAdapter) viewPagerContainer.getAdapter())
                                .getRegisteredFragment(viewPagerContainer.getCurrentItem()).redrawItems();
                    } catch (NullPointerException ignored) {
                    }
                    fab.show();
                }
            }
        });
    }

    public BaseFragment getCurrentVisibleFragment() {
        return (((SectionsPagerAdapter)
                viewPagerContainer.getAdapter()).getRegisteredFragment(viewPagerContainer.getCurrentItem()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.list_menu2, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_note:
                MainActivity.this.finish();
                break;
        }

        return mDrawerToggle.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
    }




    public class SectionsPagerAdapter extends FragmentPagerAdapter {
        private SparseArray<BaseFragment> registeredFragments = new SparseArray<>();

        public SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            /* getItem is called to instantiate the fragment for the given page. */
            switch (position) {
                case 0:
                    SavedListsFragment savedListsFragment = SavedListsFragment.getInstance();
                    registeredFragments.put(0, savedListsFragment);
                    return savedListsFragment;
                case 1:
                    ArchivedListsFragment archivedListsFragment = ArchivedListsFragment.getInstance();
                    registeredFragments.put(1, archivedListsFragment);
                    return archivedListsFragment;
                default:
                    return new Fragment();
            }

        }

        @Override
        public int getCount() {
            // Show 2 total pages (Saved lists and Archived lists).
            return 2;
        }

        public BaseFragment getRegisteredFragment(int position) {
            return registeredFragments.get(position);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return getString(R.string.saved_lists);
                case 1:
                    return getString(R.string.archived_lists);
            }
            return null;
        }

    }

    private void setupDrawer() {
        mNavigationView = findViewById(R.id.navigation_view);
        mDrawerLayout = findViewById(R.id.drawer_layout);
        mActivityTitle = getTitle().toString();

        mNavHeader = mNavigationView.getHeaderView(0);
        //mNavTitle = mNavHeader.findViewById(R.id.name);

        // mNavTitle.setText(mActivityTitle);

        mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            // This method will trigger on item Click of navigation menu
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                switch (menuItem.getItemId()) {

                    case R.id.nav_settings:
                        mDrawerLayout.closeDrawers();
                        startActivity(new Intent(MainActivity.this, SettingActivity.class));
                        break;

                    case R.id.nav_backup:
                        mDrawerLayout.closeDrawers();

                        final String inFileName1 = "/data/data/com.coconika.reminder/databases/reminderData.db";
                        final String inFileName2 = "/data/data/com.coconika.reminder/databases/tinylistdb.db";



                        File dbFile1 = new File(inFileName1);
                        File dbFile2 = new File(inFileName2);

                        try {
                            String folder_main = "backup";

                            File f = new File(Environment.getExternalStorageDirectory(), folder_main);
                            if (!f.exists()) {
                                f.mkdirs();
                            }
                            FileInputStream fis1 = new FileInputStream(dbFile1);
                            FileInputStream fis2 = new FileInputStream(dbFile2);

                            String outFileName1 = Environment.getExternalStorageDirectory()+"/backup/reminderData_copy.db";
                            String outFileName2 = Environment.getExternalStorageDirectory()+"/backup/tinylistdb_copy.db";

                            // Open the empty db as the output stream
                            OutputStream output1 = new FileOutputStream(outFileName1);
                            OutputStream output2 = new FileOutputStream(outFileName2);

                            // Transfer bytes from the inputfile to the outputfile
                            byte[] buffer1 = new byte[1024];
                            int length1;
                            while ((length1 = fis1.read(buffer1))>0){
                                output1.write(buffer1, 0, length1);
                            }


                            byte[] buffer2 = new byte[1024];
                            int length2;
                            while ((length2 = fis2.read(buffer2))>0){
                                output2.write(buffer2, 0, length2);
                            }

                            // Close the streams
                            output1.flush();
                            output1.close();
                            fis1.close();

                            output2.flush();
                            output2.close();
                            fis2.close();
                            Toast.makeText(MainActivity.this,"Database Backup successfully",Toast.LENGTH_LONG).show();
                        }
                        catch (Exception ex)
                        {
                            Toast.makeText(MainActivity.this,ex+"",Toast.LENGTH_LONG).show();
                        }

                        break;

                    case R.id.nav_restore:
                        mDrawerLayout.closeDrawers();

                        try {
                            File sd = Environment.getExternalStorageDirectory();

                            if (sd.canWrite()) {
                                String currentDBPath1 = "/data/data/com.coconika.reminder/databases/reminderData.db";
                                String backupDBPath1 = "/backup/reminderData_copy.db";
                                File currentDB1 = new File(currentDBPath1);
                                File backupDB1 = new File(sd, backupDBPath1);


                                String currentDBPath2 = "/data/data/com.coconika.reminder/databases/tinylistdb.db";
                                String backupDBPath2 = "/backup/tinylistdb_copy.db";
                                File currentDB2 = new File(currentDBPath2);
                                File backupDB2 = new File(sd, backupDBPath2);

                                if (backupDB2.exists()) {
                                    if (currentDB2.exists()) {
                                        FileChannel src2 = new FileInputStream(backupDB2).getChannel();
                                        FileChannel dst2 = new FileOutputStream(currentDB2).getChannel();
                                        dst2.transferFrom(src2, 0, src2.size());
                                        src2.close();
                                        dst2.close();
                                    }
                                }


                                if (backupDB1.exists()) {
                                    if (currentDB1.exists()) {
                                        FileChannel src1 = new FileInputStream(backupDB1).getChannel();
                                        FileChannel dst1 = new FileOutputStream(currentDB1).getChannel();
                                        dst1.transferFrom(src1, 0, src1.size());
                                        src1.close();
                                        dst1.close();
                                        Toast.makeText(getApplicationContext(), "Database Restored successfully", Toast.LENGTH_SHORT).show();
                                        AlarmManager alm = (AlarmManager) MainActivity.this.getSystemService(Context.ALARM_SERVICE);
                                        alm.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, PendingIntent.getActivity(MainActivity.this, 0, new Intent(MainActivity.this, this.getClass()), 0));
                                        android.os.Process.killProcess(android.os.Process.myPid());
                                    }
                                    else
                                    {
                                        Toast.makeText(getApplicationContext(), "Path Not Find", Toast.LENGTH_SHORT).show();

                                    }
                                }
                                else
                                {
                                    Toast.makeText(getApplicationContext(), "Database Not Find", Toast.LENGTH_SHORT).show();

                                }





                            }
                        } catch (Exception ex) {
                            Toast.makeText(MainActivity.this,ex+"",Toast.LENGTH_LONG).show();
                        }

                        break;

                    case R.id.nav_contact:
                        mDrawerLayout.closeDrawers();
                        startActivity(new Intent(MainActivity.this, contactUs.class));
                        // reloadReminders(ReminderType.NOTE);
                        break;

                    case R.id.nav_share:
                        mDrawerLayout.closeDrawers();
                        String share = "https://play.google.com/store/apps/details?id=com.coconika.reminder";
                        Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                        intent.putExtra(Intent.EXTRA_TEXT,share);
                        startActivity(Intent.createChooser(intent, "Share using?"));
                        break;

                    case R.id.nav_about:
                        mDrawerLayout.closeDrawers();
                        startActivity(new Intent(MainActivity.this, aboutUs.class));
                        break;

                    case R.id.nav_security:
                        mDrawerLayout.closeDrawers();
                        startActivity(new Intent(MainActivity.this, Security.class));
                        break;
                    case R.id.nav_pay:

                        connect_store();
                        break;

                    default:
                        break;
                }
                return true;
            }

            ;
        });
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
                R.string.drawer_open, R.string.drawer_close) {

            /** Called when a drawer has settled in a completely open state. */
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);

            }

            /** Called when a drawer has settled in a completely closed state. */
            public void onDrawerClosed(View view) {
                super.onDrawerClosed(view);
            }

        };
        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.addDrawerListener(mDrawerToggle);

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null;
    }
    public void progress()
    {
        bar = new ProgressDialog(MainActivity.this);
        bar.setCanceledOnTouchOutside(false);
        bar.setCancelable(false);
        bar.setMessage("Waiting...");
        bar.setIndeterminate(true);
        bar.show();
    }
    public void connect_store()
    {
        progress();
        bhelper = new IabHelper(this,getResources().getString(R.string.ras_key));
        bhelper.enableDebugLogging(false);
        bhelper.startSetup(new IabHelper.OnIabSetupFinishedListener()
        {
            @Override
            public void onIabSetupFinished(IabResult result)
            {

                if(result.isSuccess())
                {

                    final List<String> skulist = new ArrayList<String>();
                    skulist.add(getResources().getString(R.string.product_key));


                    ////

                    bhelper.queryInventoryAsync(true, skulist, new IabHelper.QueryInventoryFinishedListener()
                    {

                        @Override
                        public void onQueryInventoryFinished(IabResult result, Inventory inv)
                        {


                            if (bhelper != null) {
                                //     Toast.makeText(getBaseContext(), "connect", Toast.LENGTH_LONG).show();
                                remove_ads();
                            }

                            else
                            {

                                Toast.makeText(getBaseContext(), "no connection", Toast.LENGTH_LONG).show();

                            }

                        }


                    });

                }
                else
                {

                    Toast.makeText(getBaseContext(), result.getMessage(), Toast.LENGTH_LONG).show();

                }
                bar.dismiss();


            }
        });

    }
    public void remove_ads()
    {

        if (bhelper != null) {
            try {
                bhelper.flagEndAsync();
                bhelper.launchPurchaseFlow(MainActivity.this, getResources().getString(R.string.product_key), 1001, new IabHelper.OnIabPurchaseFinishedListener() {

                    @Override
                    public void onIabPurchaseFinished(IabResult result, Purchase info) {


                        if (result.isSuccess()) {
                            editorU.putInt("ads",1);
                            editorU.commit();
                            // Toast.makeText(getBaseContext(), "success", Toast.LENGTH_LONG).show();

                            return;
                        }
                        if (info.getSku().equals(getResources().getString(R.string.product_key))) {
                            //   Toast.makeText(getBaseContext(), "success", Toast.LENGTH_LONG).show();
                            editorU.putInt("ads",1);
                            editorU.commit();
                            return;
                        }

                        if (result.getResponse() == 0 || result.getResponse() == 7) {
                            editorU.putInt("ads",1);
                            editorU.commit();

                            //   Toast.makeText(getBaseContext(), "success", Toast.LENGTH_LONG).show();

                            return;
                        }


                        if (result.isFailure()) {
                            Toast.makeText(getBaseContext(), "error", Toast.LENGTH_LONG).show();
                            return;
                        }

                    }

                });
            } catch (IllegalStateException ex) {
                bhelper.flagEndAsync();
                Toast.makeText(this, "Please retry in a few seconds later.", Toast.LENGTH_SHORT).show();

            }
        } else {

            Toast.makeText(getBaseContext(),"error", Toast.LENGTH_LONG).show();
        }


    }

    @Override
    protected void onDestroy()
    {

        super.onDestroy();
        if (bhelper != null) bhelper.dispose();
        bhelper = null;

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (bhelper != null  && resultCode != RESULT_CANCELED &&  data != null)
        {
            bhelper.handleActivityResult(requestCode, resultCode, data);
        }
    }
}
