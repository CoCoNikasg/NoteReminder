package com.example.kyle.reminder;

import android.content.Context;
import android.view.WindowManager;



public class DisplayMetrics {

    private static int w , h;
    private static android.util.DisplayMetrics dm;

    public static  void  DisplayMetrics(Context context)
    {
        dm = new android.util.DisplayMetrics();
        ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE))
                .getDefaultDisplay().getMetrics(dm);



    }

    public static int get_w(Context context)
    {

        DisplayMetrics(context);
        w = dm.widthPixels;

        return  w;
    }

    public static int get_h(Context context)
    {
        DisplayMetrics(context);
        h = dm.heightPixels;

        return  h;
    }
    public static double screenInches(Context context)
    {
        dm = new android.util.DisplayMetrics();
        int dens=dm.densityDpi;
        double wi=(double)dm.widthPixels/(double)dens;
        double hi=(double)dm.heightPixels/(double)dens;
        double x = Math.pow(wi,2);
        double y = Math.pow(hi,2);
        double screenInches = Math.sqrt(x+y);


        return  screenInches;
    }


}
