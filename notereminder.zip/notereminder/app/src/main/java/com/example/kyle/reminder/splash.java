package com.example.kyle.reminder;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;


public class splash extends AppCompatActivity {
    static SharedPreferences shared;
    SharedPreferences.Editor editorU ;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        shared = this.getSharedPreferences("fonts", MODE_PRIVATE);
        editorU = shared.edit();
        if (shared.getInt("selectedtheme", 0) == 0 ){
            getTheme().applyStyle(R.style.AppTheme,true);
        } else  if (shared.getInt("selectedtheme", 0) ==1 ) {
            getTheme().applyStyle(R.style.greenTheme,true);
        } else {
            getTheme().applyStyle(R.style.violetTheme,true);
        }

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                Intent intent=new Intent(splash.this, TutorialActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP );
                splash.this.startActivity(intent);
                splash.this.finish();

            }
        },3000);


        if(!sp_exits(this,"ads"))
        {
            editorU.putInt("ads",0);
            editorU.commit();
        }


        editorU.putInt("delete_click",0);
        editorU.putInt("share_click",0);
        editorU.commit();


    }

    protected void onPause()
    {
        super.onPause();

    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();
    }
    @Override
    public void onBackPressed() {

    }
    public static boolean sp_exits(Context c, String ex) {

        return shared.contains(ex);
    }
}
