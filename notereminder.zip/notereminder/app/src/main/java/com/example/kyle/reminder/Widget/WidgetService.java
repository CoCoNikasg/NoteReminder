package com.example.kyle.reminder.Widget;

import android.content.Context;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.util.Log;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import com.example.kyle.reminder.R;
import com.example.kyle.reminder.ReminderDataHelper;

import java.util.ArrayList;
import java.util.List;


public final class WidgetService extends RemoteViewsService  {


    public static final class WidgetItem {


        public final String title;
        public final String message;

        public WidgetItem(String title,String message) {
            this.title = title;
            this.message = message;

        }
    }

    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new ListRemoteViewsFactory(getApplicationContext());
    }

    public static class ListRemoteViewsFactory implements RemoteViewsFactory {
        private final List<WidgetItem> mWidgetItems = new ArrayList<>();
        private final Context mContext;
        public ListRemoteViewsFactory(Context context) {
            mContext = context;
        }

        @Override
        public void onCreate() {


        }

        @Override
        public void onDestroy() {
            mWidgetItems.clear();
        }

        @Override
        public int getCount() {
            return mWidgetItems.size();
        }

        @Override
        public RemoteViews getViewAt(int position) {

            WidgetItem widgetItem = mWidgetItems.get(position);

            RemoteViews rv = new RemoteViews(mContext.getPackageName(), R.layout.widget_item);
            rv.setTextViewText(R.id.widget_item_title, widgetItem.title);
            rv.setTextViewText(R.id.widget_item_msg, widgetItem.message);

            Intent fillInIntent = new Intent().putExtra(WidgetProvider.EXTRA_CLICKED_FILE, widgetItem.title);
            rv.setOnClickFillInIntent(R.id.widget_item_layout, fillInIntent);


            return rv;
        }

        @Override
        public RemoteViews getLoadingView() {

            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public void onDataSetChanged() {

            mWidgetItems.clear();

            ReminderDataHelper d=new ReminderDataHelper(mContext);
            Log.i("count note", d.getnoteCount()+"");

            for (int i = 0; i < d.getnoteCount(); i++) {
                WidgetItem item = new WidgetItem("Title: " + d.select_note(i,2) , "Note: " + d.select_note(i,3) );
                mWidgetItems.add(item);
            }

        }

    }
}
