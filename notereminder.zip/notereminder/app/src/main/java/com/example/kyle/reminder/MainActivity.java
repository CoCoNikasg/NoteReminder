package com.example.kyle.reminder;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager.widget.ViewPager;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.example.kyle.reminder.Fragment.AlertFragment;
import com.example.kyle.reminder.Fragment.NoteFragment;
import com.example.kyle.reminder.Fragment.ViewPagerAdapter;
import com.example.kyle.reminder.util.IabHelper;
import com.example.kyle.reminder.util.IabResult;
import com.example.kyle.reminder.util.Inventory;
import com.example.kyle.reminder.util.Purchase;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;


import butterknife.ButterKnife;


public class MainActivity extends AppCompatActivity {

  private TextView mNavTitle;
  private ActionBarDrawerToggle mDrawerToggle;
  private String mActivityTitle;
    private DrawerLayout mDrawerLayout;
    private NavigationView mNavigationView;
  private View mNavHeader;
  private Toolbar mToolbar;
  private FragmentManager mFragmentManager;
  private TabLayout tabLayout;
  private ViewPager viewPager;
  FloatingActionButton addMyAlert;
  SharedPreferences shared;
  SharedPreferences.Editor editorU ;
    private IabHelper bhelper;
    ProgressDialog bar;
    int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    boolean doubleBackToExitPressedOnce = false;

    @Override
  public void onCreate(Bundle savedInstanceState) {

    super.onCreate(savedInstanceState);
      shared = this.getSharedPreferences("fonts", MODE_PRIVATE);
      editorU = shared.edit();
      if (shared.getInt("selectedtheme", 0) == 0 ){
        getTheme().applyStyle(R.style.AppTheme,true);
      } else  if (shared.getInt("selectedtheme", 0) ==1 ) {
        getTheme().applyStyle(R.style.greenTheme,true);
      } else {
        getTheme().applyStyle(R.style.violetTheme,true);
      }
    setContentView(R.layout.activity_main);
    ButterKnife.bind(this);
    mToolbar = findViewById(R.id.tool_baar);
   this.setSupportActionBar(mToolbar);

        tabLayout =(TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);


    if (getSupportActionBar() != null) {
      getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }



        if(!hasPermissions(this, PERMISSIONS)){
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }



      setupDrawer();

        ViewPagerAdapter adapter= new ViewPagerAdapter(getSupportFragmentManager());
        adapter.AddFragment(new AlertFragment(),getString(R.string.MyAlerts));
        adapter.AddFragment(new NoteFragment(),getString(R.string.MyNotes));


        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.beelicon);
        tabLayout.getTabAt(1).setIcon(R.drawable.notelicon);

        addMyAlert =findViewById(R.id.addmynote);
        addMyAlert.setOnClickListener(v -> {

            if(viewPager.getCurrentItem()==0)
                 startActivity(new Intent(v.getContext(), CreateOrEditAlert.class));
             else
                  startActivity(new Intent(v.getContext(), CreateOrEditNote.class));

        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.list_menu, menu);
        return true;
    }


        @Override
  protected void onPostCreate(Bundle savedInstanceState) {
    super.onPostCreate(savedInstanceState);
    mDrawerToggle.syncState();
  }

  @Override
  public void onConfigurationChanged(Configuration newConfig) {
    super.onConfigurationChanged(newConfig);
    mDrawerToggle.onConfigurationChanged(newConfig);
  }

  public boolean onOptionsItemSelected(MenuItem item) {
      super.onOptionsItemSelected(item);

      switch (item.getItemId()) {
          case R.id.action_palette:
              startActivity(new Intent(MainActivity.this, com.example.kyle.reminder.checklist.activities.MainActivity.class));
              break;


      }
    return mDrawerToggle.onOptionsItemSelected(item) || super.onOptionsItemSelected(item);
  }

  private void setupDrawer() {
    mNavigationView = findViewById(R.id.navigation_view);
    mDrawerLayout = findViewById(R.id.drawer_layout);
    mActivityTitle = getTitle().toString();
    mNavHeader = mNavigationView.getHeaderView(0);

    mNavigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

      // This method will trigger on item Click of navigation menu
      @Override
      public boolean onNavigationItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {


          case R.id.nav_settings:
            mDrawerLayout.closeDrawers();
            startActivity(new Intent(MainActivity.this,SettingActivity.class));
            break;

            case R.id.nav_backup:
                mDrawerLayout.closeDrawers();

                final String inFileName1 = "/data/data/com.coconika.reminder/databases/reminderData.db";
                final String inFileName2 = "/data/data/com.coconika.reminder/databases/tinylistdb.db";



                File dbFile1 = new File(inFileName1);
                File dbFile2 = new File(inFileName2);

                try {
                    String folder_main = "backup";

                    File f = new File(Environment.getExternalStorageDirectory(), folder_main);
                    if (!f.exists()) {
                        f.mkdirs();
                    }
                    FileInputStream fis1 = new FileInputStream(dbFile1);
                    FileInputStream fis2 = new FileInputStream(dbFile2);

                    String outFileName1 = Environment.getExternalStorageDirectory()+"/backup/reminderData_copy.db";
                    String outFileName2 = Environment.getExternalStorageDirectory()+"/backup/tinylistdb_copy.db";

                    // Open the empty db as the output stream
                    OutputStream output1 = new FileOutputStream(outFileName1);
                    OutputStream output2 = new FileOutputStream(outFileName2);

                    // Transfer bytes from the inputfile to the outputfile
                    byte[] buffer1 = new byte[1024];
                    int length1;
                    while ((length1 = fis1.read(buffer1))>0){
                        output1.write(buffer1, 0, length1);
                    }


                    byte[] buffer2 = new byte[1024];
                    int length2;
                    while ((length2 = fis2.read(buffer2))>0){
                        output2.write(buffer2, 0, length2);
                    }

                    // Close the streams
                    output1.flush();
                    output1.close();
                    fis1.close();

                    output2.flush();
                    output2.close();
                    fis2.close();
                    Toast.makeText(MainActivity.this,"Database Backup successfully",Toast.LENGTH_LONG).show();
                }
                catch (Exception ex)
                {
                    Toast.makeText(MainActivity.this,ex+"",Toast.LENGTH_LONG).show();
                }

                break;

            case R.id.nav_restore:
                mDrawerLayout.closeDrawers();

                try {
                    File sd = Environment.getExternalStorageDirectory();

                    if (sd.canWrite()) {
                        String currentDBPath1 = "/data/data/com.coconika.reminder/databases/reminderData.db";
                        String backupDBPath1 = "/backup/reminderData_copy.db";
                        File currentDB1 = new File(currentDBPath1);
                        File backupDB1 = new File(sd, backupDBPath1);


                        String currentDBPath2 = "/data/data/com.coconika.reminder/databases/tinylistdb.db";
                        String backupDBPath2 = "/backup/tinylistdb_copy.db";
                        File currentDB2 = new File(currentDBPath2);
                        File backupDB2 = new File(sd, backupDBPath2);

                        if (backupDB2.exists()) {
                            if (currentDB2.exists()) {
                                FileChannel src2 = new FileInputStream(backupDB2).getChannel();
                                FileChannel dst2 = new FileOutputStream(currentDB2).getChannel();
                                dst2.transferFrom(src2, 0, src2.size());
                                src2.close();
                                dst2.close();
                            }
                        }


                        if (backupDB1.exists()) {
                            if (currentDB1.exists()) {
                                FileChannel src1 = new FileInputStream(backupDB1).getChannel();
                                FileChannel dst1 = new FileOutputStream(currentDB1).getChannel();
                                dst1.transferFrom(src1, 0, src1.size());
                                src1.close();
                                dst1.close();
                                Toast.makeText(getApplicationContext(), "Database Restored successfully", Toast.LENGTH_SHORT).show();
                                AlarmManager alm = (AlarmManager) MainActivity.this.getSystemService(Context.ALARM_SERVICE);
                                alm.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, PendingIntent.getActivity(MainActivity.this, 0, new Intent(MainActivity.this, this.getClass()), 0));
                                android.os.Process.killProcess(android.os.Process.myPid());
                            }
                            else
                            {
                                Toast.makeText(getApplicationContext(), "Path Not Find", Toast.LENGTH_SHORT).show();

                            }
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Database Not Find", Toast.LENGTH_SHORT).show();

                        }





                    }
                } catch (Exception ex) {
                    Toast.makeText(MainActivity.this,ex+"",Toast.LENGTH_LONG).show();
                }

                break;

          case R.id.nav_contact:
            mDrawerLayout.closeDrawers();
            startActivity(new Intent(MainActivity.this,contactUs.class));
           // reloadReminders(ReminderType.NOTE);
            break;

          case R.id.nav_share:
            mDrawerLayout.closeDrawers();
            String share = "https://play.google.com/store/apps/details?id=com.coconika.reminder";
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT,share);
            startActivity(Intent.createChooser(intent, "Share using?"));
            break;

          case R.id.nav_about:
            mDrawerLayout.closeDrawers();
            startActivity(new Intent(MainActivity.this,aboutUs.class));
            break;

          case R.id.nav_security:
            mDrawerLayout.closeDrawers();
            startActivity(new Intent(MainActivity.this,Security.class));
            break;

            case R.id.nav_pay:

                connect_store();
              break;

          default:
            break;
        }
        return true;
      }


    });
    mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout,
            R.string.drawer_open, R.string.drawer_close) {


      public void onDrawerOpened(View drawerView) {
        super.onDrawerOpened(drawerView);

      }


      public void onDrawerClosed(View view) {
        super.onDrawerClosed(view);
      }

    };
    mDrawerToggle.setDrawerIndicatorEnabled(true);
    mDrawerLayout.addDrawerListener(mDrawerToggle);
  }


  @Override
  public void onBackPressed() {

      if (doubleBackToExitPressedOnce) {
          super.onBackPressed();
          return;
      }

      this.doubleBackToExitPressedOnce = true;
      Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

      new Handler().postDelayed(new Runnable() {

          @Override
          public void run() {
              doubleBackToExitPressedOnce=false;
          }
      }, 2000);
  }

    @Override
    protected void onStop()
    {
        super.onStop();
      }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }
    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null;
    }
    public void progress()
    {
        bar = new ProgressDialog(MainActivity.this);
        bar.setCanceledOnTouchOutside(false);
        bar.setCancelable(false);
        bar.setMessage("Waiting...");
        bar.setIndeterminate(true);
        bar.show();
    }
    public void connect_store()
    {
        progress();
        bhelper = new IabHelper(this,getResources().getString(R.string.ras_key));
        bhelper.enableDebugLogging(false);
        bhelper.startSetup(result -> {

            if(result.isSuccess())
            {

                final List<String> skulist = new ArrayList<String>();
                skulist.add(getResources().getString(R.string.product_key));


                ////

                bhelper.queryInventoryAsync(true, skulist, (result1, inv) -> {


                    if (bhelper != null) {
                   //     Toast.makeText(getBaseContext(), "connect", Toast.LENGTH_LONG).show();
                        remove_ads();
                    }

                    else
                    {

                        Toast.makeText(getBaseContext(), "no connection", Toast.LENGTH_LONG).show();

                    }

                });

            }
            else
            {

                Toast.makeText(getBaseContext(), result.getMessage(), Toast.LENGTH_LONG).show();

            }
            bar.dismiss();


        });

    }
    public void remove_ads()
    {

        if (bhelper != null) {
            try {
                bhelper.flagEndAsync();
                bhelper.launchPurchaseFlow(MainActivity.this, getResources().getString(R.string.product_key), 1001, new IabHelper.OnIabPurchaseFinishedListener() {

                    @Override
                    public void onIabPurchaseFinished(IabResult result, Purchase info) {


                        if (result.isSuccess()) {
                            editorU.putInt("ads",1);
                            editorU.commit();
                           // Toast.makeText(getBaseContext(), "success", Toast.LENGTH_LONG).show();

                            return;
                        }
                        if (info.getSku().equals(getResources().getString(R.string.product_key))) {
                         //   Toast.makeText(getBaseContext(), "success", Toast.LENGTH_LONG).show();
                            editorU.putInt("ads",1);
                            editorU.commit();
                            return;
                        }

                        if (result.getResponse() == 0 || result.getResponse() == 7) {
                            editorU.putInt("ads",1);
                            editorU.commit();

                         //   Toast.makeText(getBaseContext(), "success", Toast.LENGTH_LONG).show();

                            return;
                        }


                        if (result.isFailure()) {
                            Toast.makeText(getBaseContext(), "error", Toast.LENGTH_LONG).show();
                            return;
                        }

                    }

                });
            } catch (IllegalStateException ex) {
                bhelper.flagEndAsync();
                Toast.makeText(this, "Please retry in a few seconds later.", Toast.LENGTH_SHORT).show();

            }
        } else {

            Toast.makeText(getBaseContext(),"error", Toast.LENGTH_LONG).show();
        }


    }

    @Override
    protected void onDestroy()
    {

        super.onDestroy();
        if (bhelper != null) bhelper.dispose();
        bhelper = null;

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (bhelper != null  && resultCode != RESULT_CANCELED &&  data != null)
        {
            bhelper.handleActivityResult(requestCode, resultCode, data);
        }
    }

}

