package com.example.kyle.reminder;

import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import androidx.annotation.NonNull;
import androidx.core.app.NavUtils;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;


import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.github.javiersantos.materialstyleddialogs.MaterialStyledDialog;
import com.github.javiersantos.materialstyleddialogs.enums.Style;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

import java.util.ArrayList;
import java.util.Locale;


public class CreateOrEditNote extends AppCompatActivity {
  private EditText mTitle, mContent;
  private ContentResolver mContentResolver;
  private ReminderItem mData;
  private ImageView voice_typing;
  private final int REQ_CODE_SPEECH_INPUT = 245;
  private  String matn="";
  private String  id_user = "ca-app-pub-6981902959406280/3788848496";
  private InterstitialAd mInterstitialAd;
  SharedPreferences shared;
  SharedPreferences.Editor editor;
  public  int error=0;


  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    shared = this.getSharedPreferences("fonts", MODE_PRIVATE);
    editor = shared.edit();
    if (shared.getInt("selectedtheme", 0) == 0 ){
      getTheme().applyStyle(R.style.AppTheme,true);
    } else  if (shared.getInt("selectedtheme", 0) ==1 ) {
      getTheme().applyStyle(R.style.greenTheme,true);
    } else {
      getTheme().applyStyle(R.style.violetTheme,true);
    }

    setContentView(R.layout.activity_create_or_edit_note);
    mContentResolver = getContentResolver();

    Intent intent = getIntent();
    mData = intent.getParcelableExtra("data");

    mContent = findViewById(R.id.note_content);
    mTitle = findViewById(R.id.note_title);
    voice_typing = findViewById(R.id.voiceTyping);


    Toolbar toolbar = findViewById(R.id.tool_baar);
    this.setSupportActionBar(toolbar);
    ActionBar actionBar = getSupportActionBar();
    actionBar.setDisplayHomeAsUpEnabled(false);
    actionBar.setDisplayShowHomeEnabled(false);

    if (mData != null) {
      mTitle.setText(mData.getTitle());
      mContent.setText(mData.getContent());
      setActionBarTitle(actionBar, "");
    } else {
      mData = new ReminderItem();
      setActionBarTitle(actionBar, "");
    }

    voice_typing.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        startVoiceInput();
      }
    });

    mContent.setOnFocusChangeListener(new View.OnFocusChangeListener() {
      @Override
      public void onFocusChange(View v, boolean hasFocus) {

        matn=mContent.getText().toString();

      }
    });



    mInterstitialAd = new InterstitialAd(this);
    mInterstitialAd.setAdUnitId(id_user);
    mInterstitialAd.setAdListener(new AdListener() {
      @Override
      public void onAdLoaded() {

        error=0;

      }

      @Override
      public void onAdFailedToLoad(int errorCode) {
        error=1;
      }

      @Override
      public void onAdOpened() {
        // Code to be executed when the ad is displayed.
      }

      @Override
      public void onAdLeftApplication() {
        // Code to be executed when the user has left the app.
      }

      @Override
      public void onAdClosed() {
          if (shared.getInt("ads", 0) == 0 )
          {
            mInterstitialAd.loadAd(new AdRequest.Builder().build());
          }
      }
    });

    if (shared.getInt("ads", 0) == 0 )
    {
      mInterstitialAd.loadAd(new AdRequest.Builder().build());
    }
  }

  @Override
  public void onBackPressed() {
    promptSave();

  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.menu_create_or_edit_note, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {

      case R.id.action_save_note:
       // deleteDialog(mData).show();
      promptSave();
        break;

      case R.id.English:
        editor.putString("lang","en_DE");
        editor.commit();
        break;

      case R.id.French:
        editor.putString("lang","fr_FR");
        editor.commit();
        break;

      case R.id.German:
        editor.putString("lang","de_AT");
        editor.commit();
        break;

      case R.id.Persian:
        editor.putString("lang","fa_IR");
        editor.commit();
        break;

      case R.id.Arabic:
        editor.putString("lang","ar_AE");
        editor.commit();
        break;

      case R.id.Indian:
        editor.putString("lang","hi_IN");
        editor.commit();
        break;

      case R.id.Korean:
        editor.putString("lang","ko_KR");
        editor.commit();
        break;

      case R.id.Italian:
        editor.putString("lang","it_IT");
        editor.commit();
        break;

      case R.id.Spanish:
        editor.putString("lang","es_ES");
        editor.commit();
        break;

      case R.id.PhoneLang:
        editor.putString("lang",Locale.getDefault()+"");
        editor.commit();
        break;


      case android.R.id.home:
        promptSave();
        break;

      default:
        break;
    }

    return true;
  }

  private AlertDialog deleteDialog(final ReminderItem item) {
    return new AlertDialog.Builder(this)
        .setTitle("Confirm")
        .setMessage("Do you want to delete?")
        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int i) {
            deleteNote(item);

          }
        })
        .setNegativeButton("No", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface dialog, int i) {
dialog.dismiss();

}
})
        .create();
  }

  private void saveDialog(final ReminderItem item) {
    new MaterialStyledDialog.Builder(CreateOrEditNote.this)
            .setDescription(R.string.save_prompt)
            .setStyle(Style.HEADER_WITH_TITLE)
            .setTitle(R.string.confirm)
            .withIconAnimation(true)
            .withDialogAnimation(true)
            .setPositiveText(R.string.yes)
            .setNegativeText(R.string.no)
            .setScrollable(true)
            .onPositive(new MaterialDialog.SingleButtonCallback() {
              @Override
              public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                saveNote(item);
                terminateActivity();
                dialog.dismiss();

                if (shared.getInt("ads", 0) == 0 )
                {

                  if (mInterstitialAd.isLoaded()) {

                    mInterstitialAd.show();
                  }
                  else if (error==1)
                  {
                    mInterstitialAd.loadAd(new AdRequest.Builder().build());
                  }

                }
              }

            })
            .onNegative(new MaterialDialog.SingleButtonCallback() {
              @Override
              public void onClick(@NonNull MaterialDialog dialog, @NonNull DialogAction which) {
                terminateActivity();
                dialog.dismiss();
              }
            })
            .show();

  }

  private void terminateActivity() {
    NavUtils.navigateUpFromSameTask(this);
  }

  private void promptSave() {
    mData.setTitle(mTitle.getText().toString());
    mData.setContent(mContent.getText().toString());
    saveDialog(mData);
  }

  private void setActionBarTitle(ActionBar actionBar, String title) {
    if (actionBar != null) {
      actionBar.setTitle(title);
      actionBar.setDisplayHomeAsUpEnabled(false);
    }
  }

  private void saveNote(ReminderItem item) {
    if (item.getId() > 0) {
      ContentValues values = new ContentValues();
      values.put(ReminderContract.Notes.TITLE, item.getTitle());
      values.put(ReminderContract.Notes.CONTENT, item.getContent());
      Uri uri = ContentUris.withAppendedId(ReminderContract.Notes.CONTENT_URI, item.getId());
      mContentResolver.update(uri, values, null, null);
    } else {
      ContentValues values = new ContentValues();
      values.put(ReminderContract.Notes.TYPE, ReminderType.NOTE.getName());
      values.put(ReminderContract.Notes.TITLE, item.getTitle());
      values.put(ReminderContract.Notes.CONTENT, item.getContent());
      mContentResolver.insert(ReminderContract.Notes.CONTENT_URI, values);
    }
  }

  private void deleteNote(ReminderItem item) {
    if (item != null) {
      Uri uri = ContentUris.withAppendedId(ReminderContract.Notes.CONTENT_URI, item.getId());
      mContentResolver.delete(uri, null, null);
    }
    terminateActivity();


  }


  private void startVoiceInput() {
    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, shared.getString("lang",null));
    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, R.string.say_someting);
   // Toast.makeText(this, Locale.getDefault()+"", Toast.LENGTH_SHORT).show();
    try {
      startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
    } catch (ActivityNotFoundException a) {

    }
  }


  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);

    switch (requestCode) {
      case REQ_CODE_SPEECH_INPUT: {
        if (resultCode == RESULT_OK && null != data) {
          ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
          matn=mContent.getText().toString();

          matn=matn+" "+result.get(0);
          mContent.setText(matn);
        }
        break;
      }

    }
  }


}
